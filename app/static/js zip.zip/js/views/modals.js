PP.Modals = {
  async createPocket(existing = null, opts = {}) {
    const editing = !!existing;
    const colors = PP.state.colors?.length ? PP.state.colors : (await PP.MiscAPI.colors().then(r => r.data.colors).catch(() => []) || []);
    const icons = PP.state.icons?.length ? PP.state.icons : (await PP.MiscAPI.icons().then(r => r.data.icons).catch(() => []) || []);
    PP.state.colors = colors; PP.state.icons = icons;

    let selectedColor = editing ? existing.color : colors[0]?.value || '#6366f1';
    let selectedIcon = editing ? existing.icon : icons[0]?.name || 'wallet';
    let budgetAmount = editing ? existing.budget_amount || 0 : 0;
    let monthlyLimit = editing ? existing.monthly_limit || 0 : 0;
    let priority = editing ? existing.priority || 0 : 0;
    let initialBalance = 0;
    let descriptionVal = editing ? (existing.description || '') : '';
    let nameVal = editing ? existing.name : '';

    const modal = PP.UI.modal({
      title: editing ? 'Edit Pocket' : 'Create New Pocket',
      subtitle: editing ? 'Update your pocket details' : 'Organize your money with custom pockets',
      icon: editing ? 'pencil' : 'folder-plus',
      iconClass: editing ? 'bg-accent' : 'bg-success',
      size: 'lg'
    });

    const renderBody = () => {
      const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1.25rem' });
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Pocket Name *']),
        (() => {
          const inp = PP.el('input', { class: 'form-input', placeholder: 'e.g. Food, Savings, Europe Trip', maxlength: 100, value: nameVal });
          inp.oninput = () => nameVal = inp.value;
          return inp;
        })(),
      ]));
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Description (optional)']),
        (() => {
          const t = PP.el('textarea', { class: 'form-textarea', placeholder: 'What is this pocket for?', rows: 2 });
          t.value = descriptionVal;
          t.oninput = () => descriptionVal = t.value;
          return t;
        })(),
      ]));
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Color']),
        (() => {
          const g = PP.el('div', { class: 'color-grid' });
          colors.forEach(c => {
            const sw = PP.el('div', {
            class: 'color-swatch' + (selectedColor === c.value ? ' selected' : ''),
            style: `background:linear-gradient(135deg,${c.gradient?.[0] || c.value},${c.gradient?.[1] || c.value})`
          });
          sw.onclick = () => { selectedColor = c.value; renderBody(); };
          if (selectedColor === c.value) sw.appendChild(PP.el('i', { 'data-lucide': 'check', style: 'color:white;width:16px;height:16px' }));
          g.appendChild(sw);
          });
          return g;
        })(),
      ]));
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Icon']),
        (() => {
          const g = PP.el('div', { class: 'icon-grid' });
          icons.slice(0, 80).forEach(i => {
            const s = PP.el('div', {
              class: 'icon-swatch' + (selectedIcon === i.name ? ' selected' : ''),
              title: i.name
            }, [PP.el('i', { 'data-lucide': i.name })]);
            s.onclick = () => { selectedIcon = i.name; renderBody(); };
            g.appendChild(s);
          });
          return g;
        })(),
      ]));
      if (!editing) {
        body.appendChild(PP.el('div', { class: 'form-row' }, [
          PP.el('div', { class: 'form-group' }, [
            PP.el('label', { class: 'form-label' }, ['Initial Balance']),
            (() => {
              const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0', step: '0.01', placeholder: '0.00', value: initialBalance || '' });
              inp.oninput = () => initialBalance = parseFloat(inp.value) || 0;
              return inp;
            })(),
          ]),
          PP.el('div', { class: 'form-group' }, [
            PP.el('label', { class: 'form-label' }, ['Priority']),
            (() => {
              const sel = PP.el('select', { class: 'form-select' });
              [{v:0,l:'Normal'},{v:1,l:'Low'},{v:2,l:'Medium'},{v:3,l:'High'},{v:4,l:'Critical'}].forEach(o => {
                const op = PP.el('option', { value: o.v }, [o.l]);
                if (priority == o.v) op.selected = true;
                sel.appendChild(op);
              });
              sel.onchange = () => priority = parseInt(sel.value);
              return sel;
            })(),
          ]),
        ]));
      }
      body.appendChild(PP.el('div', { class: 'form-row' }, [
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Total Budget (optional)']),
          (() => {
            const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0', step: '0.01', placeholder: 'e.g. 50000', value: budgetAmount || '' });
            inp.oninput = () => budgetAmount = parseFloat(inp.value) || 0;
            return inp;
          })(),
        ]),
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Monthly Limit (optional)']),
          (() => {
            const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0', step: '0.01', placeholder: 'e.g. 10000', value: monthlyLimit || '' });
            inp.oninput = () => monthlyLimit = parseFloat(inp.value) || 0;
            return inp;
          })(),
        ]),
      ]));

      modal.body.innerHTML = '';
      modal.body.appendChild(body);
      modal.footer.innerHTML = '';
      modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      const saveBtn = PP.el('button', {
        class: 'btn btn-primary',
        onclick: async () => {
          if (!nameVal?.trim()) return PP.UI.toast('Name required', 'Please enter a pocket name', 'warning');
          saveBtn.disabled = true; saveBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Saving…';
          PP.refreshIcons();
          try {
            const payload = {
              name: nameVal.trim(),
              description: descriptionVal.trim() || null,
              color: selectedColor,
              icon: selectedIcon,
              icon_type: 'lucide',
              budget_amount: budgetAmount,
              monthly_limit: monthlyLimit,
              priority,
            };
            if (!editing) payload.initial_balance = initialBalance;
            const res = editing ? await PP.PocketsAPI.update(existing.id, payload) : await PP.PocketsAPI.create(payload);
            PP.UI.toast(editing ? 'Pocket updated' : 'Pocket created', res.message || '', 'success');
            modal.close();
            opts.onSaved?.(res?.data?.pocket);
            PP.emit('pockets:changed');
            PP.refreshCurrentView();
          } catch (e) { PP.UI.toast('Save failed', e.message, 'error'); }
          finally { saveBtn.disabled = false; saveBtn.innerHTML = editing ? 'Save Changes' : 'Create Pocket'; }
        },
      }, [editing ? 'Save Changes' : 'Create Pocket']);
      modal.footer.appendChild(saveBtn);
      PP.refreshIcons();
    };
    renderBody();
  },

  async addIncome(opts = {}) {
    const pockets = await PP.PocketsAPI.list({ per_page: 200 }).then(r => r.data.items).catch(() => PP.state.pockets || []) || [];
    PP.state.pockets = pockets;
    const rules = await PP.WalletAPI.rules({ active_only: true }).then(r => r.data?.rules || []).catch(() => []) || [];
    let step = 1; let totalAmount = 0;
    let strategy = opts.strategy || 'single';
    let singlePocketId = opts.singlePocketId || pockets[0]?.id;
    let source = 'Salary'; let descriptionVal = ''; let fromWallet = true;
    let percentages = pockets.reduce((acc, p, i) => { acc[p.id] = i === 0 ? 100 : 0; return acc; }, {});
    let fixedAmounts = pockets.reduce((acc, p) => { acc[p.id] = 0; return acc; }, {});
    let selectedRuleId = rules[0]?.id;
    let allocations = []; let summary = {};
    const modal = PP.UI.modal({ title: 'Add Income', subtitle: 'Distribute your income across pockets', icon: 'arrow-down-left', iconClass: 'bg-success', size: 'lg' });

    const renderStepper = () => PP.el('div', { class: 'stepper' },
      ['Amount','Strategy','Review'].map((label, i) => {
        const n = i + 1;
        const el = PP.el('div', { class: `step ${step === n ? 'active' : step > n ? 'done' : ''}` }, [
          PP.el('div', { class: 'step-circle' }, [step > n ? PP.el('i', { 'data-lucide': 'check', style: 'width:14px;height:14px' }) : String(n)]),
          PP.el('div', { class: 'step-label' }, [label]),
        ]);
        if (n < 3) el.appendChild(PP.el('div', { class: 'step-line' }));
        return el;
      })
    );

    const renderBody = async () => {
      const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem' });
      body.appendChild(renderStepper());
      if (step === 1) {
        body.appendChild(PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Income Amount *']),
          (() => {
            const inp = PP.el('input', { class: 'form-input', type: 'number', min: '1', step: '0.01', placeholder: 'e.g. 60000', value: totalAmount || '', style: 'font-size:1.25rem;font-weight:700' });
            inp.oninput = () => totalAmount = parseFloat(inp.value) || 0;
            setTimeout(() => inp.focus(), 50);
            return inp;
          })(),
        ]));
        body.appendChild(PP.el('div', { class: 'form-row' }, [
          PP.el('div', { class: 'form-group' }, [
            PP.el('label', { class: 'form-label' }, ['Source']),
            (() => {
              const s = PP.el('select', { class: 'form-select' });
              ['Salary','Freelance','Gift','Investment Returns','Business','Rent','Other'].forEach(opt => {
                const o = PP.el('option', {}, [opt]);
                if (source === opt) o.selected = true;
                s.appendChild(o);
              });
              s.onchange = () => source = s.value;
              return s;
            })(),
          ]),
          PP.el('div', { class: 'form-group' }, [
            PP.el('label', { class: 'form-label' }, ['Fund from']),
            (() => {
              const s = PP.el('select', { class: 'form-select' });
              const o1 = PP.el('option', { value: 'wallet' }, ['Wallet Balance']);
              const o2 = PP.el('option', { value: 'external' }, ['External (New Money)']);
              if (fromWallet) o1.selected = true; else o2.selected = true;
              s.append(o1, o2);
              s.onchange = () => fromWallet = s.value === 'wallet';
              return s;
            })(),
          ]),
        ]));
        body.appendChild(PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Notes (optional)']),
          (() => {
            const t = PP.el('textarea', { class: 'form-textarea', placeholder: 'Any details about this income?', rows: 2 });
            t.value = descriptionVal;
            t.oninput = () => descriptionVal = t.value;
            return t;
          })(),
        ]));
      }
      if (step === 2) {
        body.appendChild(PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Distribution Strategy']),
          (() => {
            const row = PP.el('div', { style: 'display:grid;grid-template-columns:repeat(2,1fr);gap:.5rem' });
            [{v:'single',l:'Single Pocket',icon:'folder'},{v:'percentage',l:'By Percentage',icon:'percent'},{v:'fixed',l:'Fixed Amounts',icon:'coins'},{v:'rule',l:'Saved Rule',icon:'bookmark'}].forEach(o => {
              const b = PP.el('button', { type: 'button', class: `btn ${strategy === o.v ? 'btn-primary' : 'btn-outline'}`, style: 'flex-direction:column;gap:.3rem;height:auto;padding:1rem;align-items:center',
                onclick: () => { strategy = o.v; renderBody(); } }, [
                PP.el('i', { 'data-lucide': o.icon, style: 'width:22px;height:22px' }),
                PP.el('span', { style: 'font-size:.82rem' }, [o.l]),
              ]);
              row.appendChild(b);
            });
            return row;
          })(),
        ]));
        if (strategy === 'single') body.appendChild(PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Select Pocket']),
          (() => {
            const sel = PP.el('select', { class: 'form-select' });
            pockets.forEach(p => { const o = PP.el('option', { value: p.id }, [`${p.name} — ${PP.fmt(p.current_balance)}`]); if (p.id == singlePocketId) o.selected = true; sel.appendChild(o); });
            sel.onchange = () => singlePocketId = parseInt(sel.value);
            return sel;
          })(),
        ]));
        if (strategy === 'percentage') {
          const pctWrap = PP.el('div', { style: 'display:flex;flex-direction:column;gap:.5rem;max-height:260px;overflow:auto;padding:.25rem' });
          let total = Object.values(percentages).reduce((a, b) => a + b, 0);
          body.appendChild(PP.el('div', { style: 'display:flex;justify-content:space-between;margin-bottom:.25rem' }, [
            PP.el('span', { class: 'form-label' }, ['Total Allocation']),
            PP.el('span', { class: 'font-semibold', style: `color:${total === 100 ? 'var(--success)' : total > 100 ? 'var(--danger)' : 'var(--warning)'}` }, [`${total.toFixed(0)}%`]),
          ]));
          pockets.forEach(p => {
            const r = PP.el('div', { style: 'display:grid;grid-template-columns:1fr 80px auto;gap:.5rem;align-items:center' });
            r.appendChild(PP.el('div', { style: 'display:flex;align-items:center;gap:.5rem' }, [
              PP.el('div', { style: `width:30px;height:30px;border-radius:8px;background:${p.color};color:white;display:flex;align-items:center;justify-content:center;flex-shrink:0` }, [PP.el('i', { 'data-lucide': p.icon, style: 'width:14px;height:14px' })]),
              PP.el('span', { style: 'font-weight:500' }, [p.name]),
            ]));
            const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0', max: '100', step: '1', value: percentages[p.id] || 0, style: 'text-align:right;padding:.5rem;font-size:.85rem' });
            inp.oninput = () => { percentages[p.id] = parseFloat(inp.value) || 0; renderBody(); };
            r.appendChild(inp);
            const amt = ((percentages[p.id] || 0) / 100 )* (totalAmount || 0);
            r.appendChild(PP.el('span', { class: 'text-muted mono', style: 'font-size:.72rem;width:80px;text-align:right' }, [PP.fmt(amt)]));
            pctWrap.appendChild(r);
          });
          body.appendChild(pctWrap);
        }
        if (strategy === 'fixed') {
          const fixWrap = PP.el('div', { style: 'display:flex;flex-direction:column;gap:.5rem;max-height:260px;overflow:auto;padding:.25rem' });
          let allocated = Object.values(fixedAmounts).reduce((a, b) => a + b, 0);
          fixWrap.appendChild(PP.el('div', { style: 'display:flex;justify-content:space-between;margin-bottom:.25rem' }, [
            PP.el('span', { class: 'form-label' }, ['Allocated']),
            PP.el('span', { class: 'font-semibold', style: `color:${Math.abs(allocated - totalAmount) < 0.01 ? 'var(--success)' : allocated > totalAmount ? 'var(--danger)' : 'var(--warning)'}` }, [`${PP.fmt(allocated)} / ${PP.fmt(totalAmount)}`]),
          ]));
          pockets.forEach(p => {
            const r = PP.el('div', { style: 'display:grid;grid-template-columns:1fr 110px;gap:.5rem;align-items:center' });
            r.appendChild(PP.el('div', { style: 'display:flex;align-items:center;gap:.5rem' }, [
              PP.el('div', { style: `width:30px;height:30px;border-radius:8px;background:${p.color};color:white;display:flex;align-items:center;justify-content:center;flex-shrink:0` }, [PP.el('i', { 'data-lucide': p.icon, style: 'width:14px;height:14px' })]),
              PP.el('span', { style: 'font-weight:500' }, [p.name]),
            ]));
            const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0', step: '0.01', value: fixedAmounts[p.id] || '', style: 'text-align:right;padding:.5rem;font-size:.85rem' });
            inp.oninput = () => { fixedAmounts[p.id] = parseFloat(inp.value) || 0; renderBody(); };
            r.appendChild(inp);
            fixWrap.appendChild(r);
          });
          body.appendChild(fixWrap);
        }
        if (strategy === 'rule') {
          if (!rules.length) body.appendChild(PP.el('div', { class: 'empty-state', style: 'padding:1.5rem' }, [
            PP.el('div', { class: 'empty-icon' }, [PP.el('i', { 'data-lucide': 'bookmark-x' })]),
            PP.el('h3', {}, ['No saved rules yet']),
            PP.el('p', {}, ['Create a distribution rule in the Wallet section.']),
          ]));
          else {
            const rulesWrap = PP.el('div', { style: 'display:flex;flex-direction:column;gap:.5rem;max-height:280px;overflow:auto;padding:.25rem' });
            rules.forEach(r => {
              const card = PP.el('div', { class: 'glass-card', style: `padding:.85rem;cursor:pointer;border:2px solid ${selectedRuleId === r.id ? 'var(--accent)' : 'var(--border)'};transition:all .18s;background:${selectedRuleId === r.id ? 'var(--hover-bg)' : ''}`,
                onclick: () => { selectedRuleId = r.id; renderBody(); } });
              card.appendChild(PP.el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;gap:.5rem' }, [
                PP.el('div', {}, [
                  PP.el('div', { style: 'font-weight:700;display:flex;align-items:center;gap:.4rem' }, [
                    r.is_default && PP.el('span', { class: 'chip success', style: 'font-size:.6rem;padding:1px 6px' }, ['Default']),
                    r.name,
                  ]),
                  PP.el('div', { class: 'text-muted text-sm', style: 'margin-top:.2rem' }, [`${r.rule_type} • ${r.allocations?.length || 0} pockets • used ${r.usage_count || 0}x`]),
                ]),
                selectedRuleId === r.id && PP.el('i', { 'data-lucide': 'check-circle-2', style: 'color:var(--success);width:20px;height:20px;flex-shrink:0' }),
              ]));
              rulesWrap.appendChild(card);
            });
            body.appendChild(rulesWrap);
          }
        }
      }
      if (step === 3) {
        body.appendChild(PP.el('div', { style: 'text-align:center;padding:2rem' }, [
          PP.el('i', { 'data-lucide': 'loader-2', style: 'animation:slowSpin 1s linear infinite;width:32px;height:32px;color:var(--accent)' }),
          PP.el('p', { style: 'margin-top:.75rem;color:var(--text-muted)' }, ['Calculating distribution…']),
        ]));
        PP.refreshIcons();
        let extras = {};
        if (strategy === 'single') extras.pocket_id = singlePocketId;
        if (strategy === 'percentage') extras.splits = pockets.filter(p => percentages[p.id] > 0).map(p => ({ pocket_id: p.id, percentage: percentages[p.id] }));
        if (strategy === 'fixed') extras.splits = pockets.filter(p => fixedAmounts[p.id] > 0).map(p => ({ pocket_id: p.id, amount: fixedAmounts[p.id] }));
        if (strategy === 'rule') extras.rule_id = selectedRuleId;
        try {
          const prev = await PP.WalletAPI.previewDistribution(totalAmount, strategy, extras);
          allocations = prev?.data?.allocations || [];
          summary = prev?.data?.summary || {};
          body.innerHTML = '';
          body.appendChild(renderStepper());
          body.appendChild(PP.el('div', { class: 'glass-card', style: 'padding:1.25rem;margin-bottom:.5rem' }, [
            PP.el('div', { style: 'display:flex;justify-content:space-between;align-items:baseline;gap:.5rem' }, [
              PP.el('div', {}, [
                PP.el('div', { class: 'text-muted text-xs', style: 'text-transform:uppercase;letter-spacing:.08em;font-weight:700' }, [`${source || 'Income'} • ${summary.strategy}`]),
                PP.el('div', { style: 'font-family:var(--font-display);font-size:2rem;font-weight:800;margin-top:.25rem' }, [PP.fmt(totalAmount)]),
                descriptionVal && PP.el('div', { class: 'text-muted text-sm', style: 'margin-top:.25rem' }, [descriptionVal]),
              ]),
              fromWallet ? PP.el('span', { class: 'chip' }, ['From Wallet']) : PP.el('span', { class: 'chip success' }, ['External']),
            ]),
          ]));
          body.appendChild(PP.el('div', { style: 'display:flex;flex-direction:column;gap:.5rem;max-height:280px;overflow:auto;padding:.25rem' },
            allocations.map(a => PP.el('div', { class: 'glass-card', style: 'padding:.75rem .9rem;display:flex;align-items:center;gap:.75rem' }, [
              PP.el('div', { style: `width:38px;height:38px;border-radius:10px;background:${a.pocket_color};color:white;display:flex;align-items:center;justify-content:center;flex-shrink:0` }, [PP.el('i', { 'data-lucide': a.pocket_icon, style: 'width:18px;height:18px' })]),
              PP.el('div', { style: 'flex:1;min-width:0' }, [
                PP.el('div', { style: 'font-weight:600' }, [a.pocket_name]),
                a.percentage != null && PP.el('div', { class: 'text-muted text-xs' }, [`${a.percentage}%`]),
              ]),
              PP.el('div', { style: 'text-align:right' }, [PP.el('div', { style: 'font-weight:700;font-family:var(--font-display)' }, [PP.fmt(a.amount)])]),
            ]))
          ));
          if (summary.remaining > 0.01) body.appendChild(PP.el('div', { class: 'chip warning', style: 'width:max-content;margin-top:.5rem' }, [
            PP.el('i', { 'data-lucide': 'alert-triangle', style: 'width:14px;height:14px' }),
            `${PP.fmt(summary.remaining)} unallocated will remain.`,
          ]));
        } catch (e) { body.innerHTML = ''; body.appendChild(renderStepper()); body.appendChild(PP.el('div', { class: 'empty-state' }, [
          PP.el('div', { class: 'empty-icon' }, [PP.el('i', { 'data-lucide': 'alert-circle' })]), PP.el('h3', {}, ['Preview failed']), PP.el('p', {}, [e.message || 'Unable to calculate distribution'])])); }
      }
      modal.body.innerHTML = ''; modal.body.appendChild(body);
      modal.footer.innerHTML = '';
      modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      let nextBtn;
      if (step < 3) {
        if (step > 1) modal.footer.appendChild(PP.el('button', { class: 'btn btn-outline', onclick: () => { step--; renderBody(); } }, [PP.el('i', { 'data-lucide': 'arrow-left', style: 'width:15px;height:15px' }), 'Back']));
        nextBtn = PP.el('button', { class: 'btn btn-primary', onclick: () => {
          if (step === 1 && !(totalAmount > 0)) return PP.UI.toast('Enter amount', 'Please enter a valid income amount', 'warning');
          if (step === 2 && strategy === 'percentage') {
            const total = Object.values(percentages).reduce((a, b) => a + b, 0);
            if (total > 100.01) return PP.UI.toast('Over 100%', `Percentages sum to ${total}%`, 'warning');
          }
          if (step === 2 && strategy === 'fixed') {
            const total = Object.values(fixedAmounts).reduce((a, b) => a + b, 0);
            if (total - 0.01 > totalAmount) return PP.UI.toast('Amount exceeded', `Fixed amounts (${PP.fmt(total)}) exceed ${PP.fmt(totalAmount)}`, 'warning');
          }
          step++; renderBody();
        }}, [step === 2 ? 'Review' : 'Next', PP.el('i', { 'data-lucide': 'arrow-right', style: 'width:15px;height:15px' })]);
        modal.footer.appendChild(nextBtn);
      } else {
        modal.footer.appendChild(PP.el('button', { class: 'btn btn-outline', onclick: () => { step = 2; renderBody(); } }, [PP.el('i', { 'data-lucide': 'arrow-left', style: 'width:15px;height:15px' }), 'Back']));
        const confirmBtn = PP.el('button', { class: 'btn btn-success', onclick: async () => {
          confirmBtn.disabled = true;
          confirmBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Processing…';
          PP.refreshIcons();
          try {
            let extras = {};
            if (strategy === 'single') extras.pocket_id = singlePocketId;
            if (strategy === 'percentage') extras.splits = pockets.filter(p => percentages[p.id] > 0).map(p => ({ pocket_id: p.id, percentage: percentages[p.id] }));
            if (strategy === 'fixed') extras.splits = pockets.filter(p => fixedAmounts[p.id] > 0).map(p => ({ pocket_id: p.id, amount: fixedAmounts[p.id] }));
            if (strategy === 'rule') extras.rule_id = selectedRuleId;
            extras.source = source; extras.description = descriptionVal || source;
            const res = await PP.WalletAPI.executeDistribution(totalAmount, strategy, extras);
            modal.close();
            PP.UI.showSuccess({ title: 'Income Distributed', subtitle: `${PP.fmt(summary?.total_allocated || totalAmount)} has been distributed`, meta: { 'Source': source, 'Pockets': `${res?.data?.pockets_updated || allocations?.length || 0} pockets`, 'Strategy': strategy } });
            opts.onDone?.();
            PP.emit('pockets:changed'); PP.emit('transactions:changed'); PP.refreshCurrentView();
          } catch (e) { PP.UI.toast('Distribution failed', e.message, 'error'); }
          finally { confirmBtn.disabled = false; confirmBtn.innerHTML = [PP.el('i', { 'data-lucide': 'check-circle-2', style: 'width:16px;height:16px' }), 'Confirm & Distribute']; }
        }}, [PP.el('i', { 'data-lucide': 'check-circle-2', style: 'width:16px;height:16px' }), 'Confirm & Distribute']);
        modal.footer.appendChild(confirmBtn);
      }
      PP.refreshIcons();
    };
    await renderBody();
  },

  async addExpense(preselectedPocketId = null, opts = {}) {
    const pockets = await PP.PocketsAPI.list({ per_page: 200 }).then(r => r.data.items).catch(() => PP.state.pockets || []) || [];
    PP.state.pockets = pockets;
    const categories = PP.state.categories?.length ? PP.state.categories : await PP.WalletAPI.categories().then(r => r.data.categories).catch(() => []) || [];
    PP.state.categories = categories;
    let step = 1; let pocketId = preselectedPocketId || pockets[0]?.id; let amount = 0;
    let category = categories[0] || 'Custom'; let descriptionVal = ''; let merchantVal = '';
    let prev;
    const modal = PP.UI.modal({ title: 'Make Payment', subtitle: 'Pay securely from your pocket', icon: 'arrow-up-right', iconClass: 'bg-danger', size: 'lg' });
    const stepper = () => PP.el('div', { class: 'stepper' },
      ['Pocket','Amount','Category','Review'].map((label, i) => {
        const n = i + 1;
        const s = PP.el('div', { class: `step ${step === n ? 'active' : step > n ? 'done' : ''}` }, [
          PP.el('div', { class: 'step-circle' }, [step > n ? PP.el('i', { 'data-lucide': 'check', style: 'width:14px;height:14px' }) : String(n)]),
          PP.el('div', { class: 'step-label' }, [label]),
        ]);
        if (n < 4) s.appendChild(PP.el('div', { class: 'step-line' }));
        return s;
      })
    );
    const renderBody = async () => {
      const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem' });
      body.appendChild(stepper());
      if (step === 1) {
        body.appendChild(PP.el('div', { class: 'form-group' }, [PP.el('label', { class: 'form-label' }, ['Select Pocket *'])]));
        const grid = PP.el('div', { style: 'display:grid;grid-template-columns:repeat(2,1fr);gap:.5rem;max-height:320px;overflow:auto;padding:.25rem' });
        pockets.forEach(p => {
          const card = PP.el('div', {
            class: 'glass-card pocket-card',
            style: Object.entries({ ...PP.UI.pocketStyleVars(p), padding: '.85rem', cursor: 'pointer',
              border: pocketId === p.id ? '2px solid var(--accent)' : '1px solid var(--border)',
              background: pocketId === p.id ? 'var(--hover-bg)' : '',
              opacity: p.archived ? '.5' : '1',
              pointerEvents: p.archived ? 'none' : 'auto',
            }).reduce((s, [k, v]) => `${s}${k}:${typeof v === 'number' ? v : v};`, ''),
            onclick: () => { pocketId = p.id; renderBody(); }
          });
          card.appendChild(PP.el('div', { class: 'pocket-card-inner' }, [
            PP.el('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, [
              PP.el('div', { style: 'display:flex;align-items:center;gap:.5rem' }, [
                PP.el('div', { style: `width:34px;height:34px;border-radius:10px;background:${p.color};color:white;display:flex;align-items:center;justify-content:center` }, [PP.el('i', { 'data-lucide': p.icon, style: 'width:16px;height:16px' })]),
                PP.el('span', { style: 'font-weight:700' }, [p.name]),
              ]),
              pocketId === p.id && PP.el('i', { 'data-lucide': 'check-circle-2', style: 'color:var(--success);width:18px;height:18px' }),
            ]),
            PP.el('div', { style: 'margin-top:.5rem' }, [
              PP.el('div', { style: 'font-family:var(--font-display);font-weight:800;font-size:1.1rem' }, [PP.fmt(p.current_balance)]),
              p.monthly_limit > 0 && PP.el('div', { class: 'pocket-progress', style: 'margin-top:.5rem;height:5px' }, [
                PP.el('div', { class: 'pocket-progress-fill', style: `width:${Math.min(100, p.budget_usage_percent || 0)}%` }),
              ]),
            ]),
          ]));
          grid.appendChild(card);
        });
        body.appendChild(grid);
      }
      if (step === 2) {
        const pocket = pockets.find(p => p.id == pocketId);
        if (pocket) body.appendChild(PP.el('div', {
          class: 'glass-card',
          style: Object.entries(PP.UI.pocketStyleVars(pocket)).reduce((s, [k, v]) => `${s}${k}:${typeof v === 'number' ? v : v};`, '') + 'padding:1rem;display:flex;align-items:center;gap:.75rem',
        }, [
          PP.el('div', { style: `width:44px;height:44px;border-radius:12px;background:${pocket.color};color:white;display:flex;align-items:center;justify-content:center` }, [PP.el('i', { 'data-lucide': pocket.icon, style: 'width:20px;height:20px' })]),
          PP.el('div', { style: 'flex:1' }, [PP.el('div', { style: 'font-weight:700' }, [pocket.name]), PP.el('div', { class: 'text-muted text-sm' }, ['Available balance'])]),
          PP.el('div', { style: 'text-align:right' }, [
    PP.el('div', { style: 'font-family:var(--font-display);font-size:1.2rem;font-weight:800' }, [
        PP.fmt(pocket.current_balance)
    ])
          ])
        ]));

        body.appendChild(PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Amount *']),
          (() => {
            const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0.01', step: '0.01', placeholder: '0.00', value: amount || '', style: 'font-size:1.5rem;font-weight:700;padding:1rem' });
            inp.oninput = () => amount = parseFloat(inp.value) || 0;
            setTimeout(() => inp.focus(), 50);
            return inp;
          })(),
        ]));
        body.appendChild(PP.el('div', { class: 'form-row' }, [
          PP.el('div', { class: 'form-group' }, [
            PP.el('label', { class: 'form-label' }, ['Merchant (optional)']),
            (() => {
              const inp = PP.el('input', { class: 'form-input', placeholder: 'e.g. Amazon, Starbucks', value: merchantVal });
              inp.oninput = () => merchantVal = inp.value;
              return inp;
            })(),
          ]),
          PP.el('div', { class: 'form-group' }, [
            PP.el('label', { class: 'form-label' }, ['Notes (optional)']),
            (() => {
              const inp = PP.el('input', { class: 'form-input', placeholder: 'e.g. Monthly groceries', value: descriptionVal });
              inp.oninput = () => descriptionVal = inp.value;
              return inp;
            })(),
          ]),
        ]));
      }
      if (step === 3) {
        body.appendChild(PP.el('div', { class: 'form-group' }, [PP.el('label', { class: 'form-label' }, ['Select Category'])]));
        const chips = PP.el('div', { style: 'display:flex;flex-wrap:wrap;gap:.4rem;max-height:320px;overflow:auto;padding:.25rem' });
        categories.forEach(c => {
          const chip = PP.el('button', { type: 'button', class: `chip ${category === c ? 'active' : ''}`, onclick: () => { category = c; renderBody(); } }, [c]);
          chips.appendChild(chip);
        });
        body.appendChild(chips);
      }
      if (step === 4) {
        body.appendChild(PP.el('div', { style: 'text-align:center;padding:2rem' }, [
          PP.el('i', { 'data-lucide': 'loader-2', style: 'animation:slowSpin 1s linear infinite;width:32px;height:32px;color:var(--accent)' }),
        ]));
        PP.refreshIcons();
        try {
          prev = await PP.TxAPI.previewExpense(pocketId, amount, { category, description: descriptionVal, merchant: merchantVal });
          const canAfford = prev?.data?.can_afford;
          const pocket = prev?.data?.pocket;
          const alt = prev?.data?.alternate_pockets || [];
          body.innerHTML = '';
          body.appendChild(stepper());
          body.appendChild(PP.el('div', { class: 'glass-card', style: `padding:1.25rem;border:2px solid ${canAfford ? 'var(--border-strong)' : 'var(--danger)'}` }, [
            PP.el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;flex-wrap:wrap' }, [
              PP.el('div', { style: 'display:flex;align-items:center;gap:.75rem' }, [
                PP.el('div', { style: `width:48px;height:48px;border-radius:14px;background:${pocket?.color || '#6366f1'};color:white;display:flex;align-items:center;justify-content:center` }, [PP.el('i', { 'data-lucide': pocket?.icon || 'wallet', style: 'width:22px;height:22px' })]),
                PP.el('div', {}, [
                  PP.el('div', { style: 'font-size:.75rem;color:var(--text-muted);font-weight:600;text-transform:uppercase;letter-spacing:.08em' }, ['From Pocket']),
                  PP.el('div', { style: 'font-size:1rem;font-weight:700' }, [pocket?.name || 'Pocket']),
                ]),
              ]),
              PP.el('div', { style: 'text-align:right' }, [
                PP.el('div', { style: 'font-size:.75rem;color:var(--text-muted);font-weight:600;text-transform:uppercase;letter-spacing:.08em' }, ['Amount']),
                PP.el('div', { style: 'font-family:var(--font-display);font-size:2rem;font-weight:800;color:var(--danger)' }, [PP.fmt(amount)]),
              ]),
            ]),
            PP.el('div', { style: 'height:1px;background:var(--border);margin:1rem 0' }),
            PP.el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:.75rem' }, [
              PP.el('div', {}, [PP.el('div', { class: 'text-xs', style: 'text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:var(--text-dim)' }, ['Balance Before']), PP.el('div', { style: 'font-family:var(--font-display);font-size:1.05rem;font-weight:700;margin-top:.15rem' }, [PP.fmt(prev?.data?.balance_before || 0)])]),
              PP.el('div', {}, [PP.el('div', { class: 'text-xs', style: 'text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:var(--text-dim)' }, ['Balance After']), PP.el('div', { style: `font-family:var(--font-display);font-size:1.05rem;font-weight:700;margin-top:.15rem;color:${canAfford ? 'var(--text)' : 'var(--danger)'}` }, [PP.fmt(prev?.data?.balance_after || 0)])]),
              PP.el('div', {}, [PP.el('div', { class: 'text-xs', style: 'text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:var(--text-dim)' }, ['Category']), PP.el('div', { style: 'font-weight:600;margin-top:.15rem' }, [category])]),
              merchantVal && PP.el('div', {}, [PP.el('div', { class: 'text-xs', style: 'text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:var(--text-dim)' }, ['Merchant']), PP.el('div', { style: 'font-weight:600;margin-top:.15rem' }, [merchantVal])]),
            ]),
          ]));
          if (!canAfford) {
            body.appendChild(PP.el('div', { class: 'glass-card', style: 'padding:1rem;border:2px solid var(--danger);background:rgba(239,68,68,.08)' }, [
              PP.el('div', { style: 'display:flex;gap:.75rem;align-items:flex-start' }, [
                PP.el('div', { style: 'width:40px;height:40px;border-radius:12px;background:rgba(239,68,68,.15);color:var(--danger);display:flex;align-items:center;justify-content:center;flex-shrink:0' }, [PP.el('i', { 'data-lucide': 'alert-triangle', style: 'width:20px;height:20px' })]),
                PP.el('div', {}, [
                  PP.el('div', { style: 'font-weight:700;font-size:1rem' }, [`Your ${pocket?.name || ''} Pocket has only ${PP.fmt(pocket?.current_balance || 0)} remaining.`]),
                  PP.el('div', { class: 'text-muted text-sm', style: 'margin-top:.25rem' }, [`You need ${PP.fmt(prev?.data?.required_amount - prev?.data?.pocket_balance || 0)} more.`]),
                  PP.el('div', { style: 'display:flex;gap:.5rem;margin-top:.75rem;flex-wrap:wrap' }, [
                    alt.length > 0 && PP.el('button', { class: 'btn btn-primary btn-sm', onclick: () => { pocketId = alt[0].id; step = 1; renderBody(); } }, [PP.el('i', { 'data-lucide': 'wallet-cards', style: 'width:14px;height:14px' }), `Use ${alt[0].name} (${PP.fmt(alt[0].current_balance)})`]),
                    PP.el('button', { class: 'btn btn-outline btn-sm', onclick: () => { modal.close(); PP.Modals.transfer({ toPocketId: pocketId }); } }, [PP.el('i', { 'data-lucide': 'refresh-ccw', style: 'width:14px;height:14px' }), 'Transfer Money']),
                    PP.el('button', { class: 'btn btn-ghost btn-sm', onclick: () => { step = 1; renderBody(); } }, ['Change Pocket']),
                  ]),
                ]),
              ]),
            ]));
          }
        } catch (e) { body.innerHTML = ''; body.appendChild(stepper()); body.appendChild(PP.el('div', { class: 'empty-state' }, [PP.el('div', { class: 'empty-icon' }, [PP.el('i', { 'data-lucide': 'alert-circle' })]), PP.el('h3', {}, ['Preview failed']), PP.el('p', {}, [e.message || 'Error'])])); }
      }
      modal.body.innerHTML = ''; modal.body.appendChild(body);
      modal.footer.innerHTML = '';
      modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      let nextBtn;
      if (step < 4) {
        if (step > 1) modal.footer.appendChild(PP.el('button', { class: 'btn btn-outline', onclick: () => { step--; renderBody(); } }, [PP.el('i', { 'data-lucide': 'arrow-left', style: 'width:15px;height:15px' }), 'Back']));
        const labels = ['Choose Amount', 'Pick Category', 'Review'];
        nextBtn = PP.el('button', { class: 'btn btn-primary', onclick: () => {
          if (step === 1 && !pocketId) return PP.UI.toast('Select pocket', 'Please choose a pocket', 'warning');
          if (step === 2 && !(amount > 0)) return PP.UI.toast('Enter amount', 'Please enter a valid amount', 'warning');
          step++; renderBody();
        }}, [labels[step - 1], PP.el('i', { 'data-lucide': 'arrow-right', style: 'width:15px;height:15px' })]);
        modal.footer.appendChild(nextBtn);
      } else {
        modal.footer.appendChild(PP.el('button', { class: 'btn btn-outline', onclick: () => { step = 3; renderBody(); } }, [PP.el('i', { 'data-lucide': 'arrow-left', style: 'width:15px;height:15px' }), 'Back']));
        const payBtn = PP.el('button', { class: 'btn btn-danger', disabled: !prev?.data?.can_afford, onclick: async () => {
          try {
            const pin = await PP.UI.pinPrompt({ title: 'Confirm Payment', subtitle: `Pay ${PP.fmt(amount)} from ${prev?.data?.pocket?.name || 'Pocket'}` });
            if (!pin) return;
            payBtn.disabled = true; payBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Processing…';
            PP.refreshIcons();
            const res = await PP.TxAPI.executeExpense(pocketId, amount, pin, { category, description: descriptionVal, merchant: merchantVal });
            modal.close();
            PP.UI.showSuccess({ title: 'Payment Successful', subtitle: `${PP.fmt(amount)} paid from ${prev?.data?.pocket?.name || 'Pocket'}`, meta: { 'Category': category, 'Merchant': merchantVal || '—', 'Pocket balance': PP.fmt(res?.data?.pocket_balance || 0) } });
            opts.onDone?.(); PP.emit('transactions:changed'); PP.emit('pockets:changed'); PP.refreshCurrentView();
          } catch (e) {
            if (e.status === 400 && e.data?.code === 'INSUFFICIENT_BALANCE') { PP.UI.toast('Insufficient balance', e.message, 'error'); step = 1; renderBody(); }
            else PP.UI.toast('Payment failed', e.message, 'error');
          } finally { payBtn.disabled = false; payBtn.innerHTML = [PP.el('i', { 'data-lucide': 'lock', style: 'width:16px;height:16px' }), 'Confirm & Pay']; }
        }}, [PP.el('i', { 'data-lucide': 'lock', style: 'width:16px;height:16px' }), 'Confirm & Pay']);
        modal.footer.appendChild(payBtn);
      }
      PP.refreshIcons();
    };
    await renderBody();
  },

  async transfer(opts = {}) {
    const pockets = await PP.PocketsAPI.list({ per_page: 200 }).then(r => r.data.items).catch(() => PP.state.pockets || []) || [];
    const active = pockets.filter(p => !p.archived);
    let fromId = opts.fromPocketId || active[0]?.id;
    let toId = opts.toPocketId || (active.find(p => p.id != fromId)?.id);
    let amount = 0; let desc = '';
    const modal = PP.UI.modal({ title: 'Transfer Between Pockets', subtitle: 'Move money instantly between your pockets', icon: 'refresh-ccw', iconClass: 'bg-info', size: 'md' });
    const renderBody = () => {
      const fromP = active.find(p => p.id == fromId);
      const toP = active.find(p => p.id == toId);
      const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem' });
      const swapRow = PP.el('div', { style: 'display:grid;grid-template-columns:1fr auto 1fr;gap:.5rem;align-items:end' });
      const pocketSel = (label, selected, onChange, exclude) => PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, [label]),
        (() => {
          const s = PP.el('select', { class: 'form-select', style: 'padding:.75rem;font-weight:600' });
          active.forEach(p => { if (p.id === exclude) return; const o = PP.el('option', { value: p.id }, [`${p.name} — ${PP.fmt(p.current_balance)}`]); if (p.id == selected) o.selected = true; s.appendChild(o); });
          s.onchange = () => onChange(parseInt(s.value));
          return s;
        })(),
      ]);
      swapRow.appendChild(pocketSel('From Pocket', fromId, (v) => { fromId = v; renderBody(); }, toId));
      swapRow.appendChild(PP.el('button', { class: 'btn-icon', style: 'margin-bottom:4px', title: 'Swap', onclick: () => { [fromId, toId] = [toId, fromId]; renderBody(); } }, [PP.el('i', { 'data-lucide': 'arrow-left-right', style: 'width:16px;height:16px' })]));
      swapRow.appendChild(pocketSel('To Pocket', toId, (v) => { toId = v; renderBody(); }, fromId));
      body.appendChild(swapRow);
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Amount *']),
        (() => { const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0.01', step: '0.01', placeholder: '0.00', value: amount || '', style: 'font-size:1.25rem;font-weight:700' }); inp.oninput = () => amount = parseFloat(inp.value) || 0; setTimeout(() => inp.focus(), 50); return inp; })(),
      ]));
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Note (optional)']),
        (() => { const inp = PP.el('input', { class: 'form-input', placeholder: 'e.g. Reallocating budget', value: desc }); inp.oninput = () => desc = inp.value; return inp; })(),
      ]));
      if (fromP && amount > 0) {
        body.appendChild(PP.el('div', { class: 'glass-card', style: `padding:1rem;border:1px solid ${fromP.current_balance >= amount ? 'var(--border-strong)' : 'var(--danger)'}` }, [
          PP.el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:.75rem' }, [
            PP.el('div', {}, [PP.el('div', { class: 'text-xs', style: 'text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:var(--text-dim)' }, [fromP.name + ' After']), PP.el('div', { style: 'font-family:var(--font-display);font-weight:800;font-size:1.1rem;margin-top:.15rem' }, [PP.fmt(fromP.current_balance - amount)])]),
            PP.el('div', {}, [PP.el('div', { class: 'text-xs', style: 'text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:var(--text-dim)' }, [(toP?.name || 'Pocket') + ' After']), PP.el('div', { style: 'font-family:var(--font-display);font-weight:800;font-size:1.1rem;margin-top:.15rem;color:var(--success)' }, [PP.fmt((toP?.current_balance || 0) + amount)])]),
          ]),
          fromP.current_balance < amount && PP.el('div', { style: 'color:var(--danger);font-weight:600;margin-top:.5rem;font-size:.85rem;display:flex;align-items:center;gap:.3rem' }, [
            PP.el('i', { 'data-lucide': 'alert-triangle', style: 'width:14px;height:14px' }), `Insufficient balance: ${fromP.name} has only ${PP.fmt(fromP.current_balance)}`,
          ]),
        ]));
      }
      modal.body.innerHTML = ''; modal.body.appendChild(body);
      modal.footer.innerHTML = '';
      modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      const txBtn = PP.el('button', { class: 'btn btn-primary', onclick: async () => {
        if (!(amount > 0)) return PP.UI.toast('Enter amount', 'Please enter a valid amount', 'warning');
        if (fromId == toId) return PP.UI.toast('Same pocket', 'Choose different pockets', 'warning');
        try {
          const pin = await PP.UI.pinPrompt({ title: 'Confirm Transfer', subtitle: `Transfer ${PP.fmt(amount)} between pockets` });
          if (!pin) return;
          txBtn.disabled = true; txBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Transferring…';
          PP.refreshIcons();
          await PP.TxAPI.transferPockets(fromId, toId, amount, pin, desc || undefined);
          modal.close();
          PP.UI.showSuccess({ title: 'Transfer Complete', subtitle: `${PP.fmt(amount)} transferred successfully`, meta: { 'From': active.find(p => p.id == fromId)?.name || '', 'To': active.find(p => p.id == toId)?.name || '' } });
          PP.emit('pockets:changed'); PP.emit('transactions:changed'); PP.refreshCurrentView();
        } catch (e) { PP.UI.toast('Transfer failed', e.message, 'error'); }
        finally { txBtn.disabled = false; txBtn.innerHTML = [PP.el('i', { 'data-lucide': 'refresh-ccw', style: 'width:16px;height:16px' }), 'Confirm Transfer']; }
      }}, [PP.el('i', { 'data-lucide': 'refresh-ccw', style: 'width:16px;height:16px' }), 'Confirm Transfer']);
      modal.footer.appendChild(txBtn);
      PP.refreshIcons();
    };
    renderBody();
  },

  setupPin() {
    let pin1 = ''; let pin2 = ''; let step = 1;
    const modal = PP.UI.modal({ title: 'Set Transaction PIN', subtitle: 'Choose a 4-digit PIN for payments and transfers', icon: 'shield-check', iconClass: 'bg-accent', size: 'sm', closable: false });
    const renderBody = () => {
      const sub = modal.root?.querySelector('.modal-subtitle');
      if (sub) sub.textContent = step === 1 ? 'Choose a 4-digit PIN for payments and transfers' : 'Re-enter the same PIN to confirm';
      const dots = []; let entered = [];
      const display = PP.el('div', { class: 'pin-display' }, Array.from({ length: 4 }, (_, i) => { const d = PP.el('div', { class: 'pin-dot' }); dots.push(d); return d; }));
      const update = () => dots.forEach((d, i) => d.classList.toggle('filled', i < entered.length));
      const pad = PP.el('div', { class: 'pin-pad' });
      const body = PP.el('div', {}, [
        PP.el('div', { style: 'text-align:center;margin-bottom:.5rem;font-weight:600;font-size:1rem' }, [step === 1 ? 'Enter 4-digit PIN' : 'Confirm 4-digit PIN']),
        display, pad,
      ]);
      [1,2,3,4,5,6,7,8,9,null,0,'del'].forEach(n => {
        if (n === null) return pad.appendChild(PP.el('div', { style: 'width:1px;height:1px' }));
        const btn = PP.el('button', { class: 'pin-btn' }, [n === 'del' ? PP.el('i', { 'data-lucide': 'delete' }) : String(n)]);
        btn.onclick = () => {
          if (n === 'del') { entered.pop(); return update(); }
          if (entered.length >= 4) return;
          entered.push(String(n)); update();
          if (entered.length === 4) setTimeout(async () => {
            if (step === 1) { pin1 = entered.join(''); step = 2; entered = []; renderBody(); }
            else {
              pin2 = entered.join('');
              if (pin1 !== pin2) { PP.UI.toast('PINs do not match', 'Please try again', 'error'); step = 1; pin1 = ''; entered = []; renderBody(); }
              else {
                try { await PP.Auth.setupPin(pin1, pin2); PP.UI.toast('PIN set', 'Your transaction PIN has been configured', 'success'); modal.close(); PP.state.user = (await PP.Auth.me()).data.user; PP.refreshUserChrome(); }
                catch (e) { PP.UI.toast('PIN setup failed', e.message, 'error'); }
              }
            }
          }, 220);
        };
        pad.appendChild(btn);
      });
      modal.body.innerHTML = ''; modal.body.appendChild(body);
      modal.footer.innerHTML = '';
      if (step === 2) modal.footer.appendChild(PP.el('button', { class: 'btn btn-outline', onclick: () => { step = 1; entered = []; renderBody(); } }, ['Back']));
      modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      PP.refreshIcons();
    };
    renderBody();
  },

  topup() {
    let amount = 0; let method = 'upi';
    const modal = PP.UI.modal({ title: 'Top Up Wallet', subtitle: 'Add money to your main wallet balance', icon: 'plus', iconClass: 'bg-success', size: 'md' });
    const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem' });
    body.appendChild(PP.el('div', { class: 'form-group' }, [
      PP.el('label', { class: 'form-label' }, ['Amount']),
      (() => {
        const inp = PP.el('input', { class: 'form-input', type: 'number', min: '1', step: '0.01', placeholder: '0.00', value: '', style: 'font-size:1.25rem;font-weight:700' });
        inp.oninput = () => amount = parseFloat(inp.value) || 0; setTimeout(() => inp.focus(), 50); return inp;
      })(),
    ]));
    body.appendChild(PP.el('div', { style: 'display:flex;gap:.4rem;flex-wrap:wrap' }, [500, 1000, 2000, 5000, 10000].map(q => PP.el('button', { class: 'btn btn-outline btn-sm', type: 'button', onclick: () => { amount = q; body.querySelector('.form-input').value = q; } }, [PP.fmt(q)]))));
    body.appendChild(PP.el('div', { class: 'form-group' }, [
      PP.el('label', { class: 'form-label' }, ['Payment Method']),
      (() => {
        const s = PP.el('select', { class: 'form-select' });
        [['upi', 'UPI'], ['card', 'Card'], ['netbanking', 'Net Banking'], ['wallet', 'External Wallet']].forEach(m => { const o = PP.el('option', { value: m[0] }, [m[1]]); s.appendChild(o); });
        s.onchange = () => method = s.value;
        return s;
      })(),
    ]));
    modal.body.innerHTML = ''; modal.body.appendChild(body);
    modal.footer.innerHTML = '';
    modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
    const addBtn = PP.el('button', { class: 'btn btn-success', onclick: async () => {
      if (!(amount > 0)) return PP.UI.toast('Invalid amount', 'Please enter a valid amount', 'warning');
      try {
        addBtn.disabled = true; addBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Processing…'; PP.refreshIcons();
        const res = await PP.WalletAPI.topup(amount, method);
        modal.close();
        PP.UI.showSuccess({ title: 'Wallet Topped Up', subtitle: `${PP.fmt(amount)} has been added to your wallet`, meta: { 'Method': method.toUpperCase(), 'New wallet balance': PP.fmt(res?.data?.new_balance || 0) } });
        PP.emit('transactions:changed'); PP.refreshCurrentView();
      } catch (e) { PP.UI.toast('Top-up failed', e.message, 'error'); }
      finally { addBtn.disabled = false; addBtn.innerHTML = ['Add Money']; }
    }}, ['Add Money']);
    modal.footer.appendChild(addBtn);
    PP.refreshIcons();
  },

  withdraw() {
    let amount = 0; let descriptionVal = '';
    const modal = PP.UI.modal({ title: 'Withdraw from Wallet', subtitle: `Available balance: ${PP.fmt(PP.state.user?.wallet_balance || 0)}`, icon: 'arrow-up-right', iconClass: 'bg-warning', size: 'md' });
    const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem' });
    body.appendChild(PP.el('div', { class: 'form-group' }, [
      PP.el('label', { class: 'form-label' }, ['Withdraw Amount']),
      (() => { const inp = PP.el('input', { class: 'form-input', type: 'number', min: '1', step: '0.01', placeholder: '0.00', style: 'font-size:1.25rem;font-weight:700' }); inp.oninput = () => amount = parseFloat(inp.value) || 0; setTimeout(() => inp.focus(), 50); return inp; })(),
    ]));
    body.appendChild(PP.el('div', { class: 'form-group' }, [
      PP.el('label', { class: 'form-label' }, ['Description (optional)']),
      (() => { const t = PP.el('textarea', { class: 'form-textarea', rows: 2, placeholder: 'e.g. Transfer to bank' }); t.oninput = () => descriptionVal = t.value; return t; })(),
    ]));
    modal.body.innerHTML = ''; modal.body.appendChild(body);
    modal.footer.innerHTML = '';
    modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
    const wdBtn = PP.el('button', { class: 'btn btn-warning', onclick: async () => {
      if (!(amount > 0)) return PP.UI.toast('Invalid amount', 'Please enter a valid amount', 'warning');
      try {
        const pin = await PP.UI.pinPrompt({ title: 'Confirm Withdrawal', subtitle: `Withdraw ${PP.fmt(amount)} from wallet` });
        if (!pin) return;
        wdBtn.disabled = true; wdBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Processing…'; PP.refreshIcons();
        const res = await PP.WalletAPI.withdraw(amount, descriptionVal.trim() || undefined);
        modal.close();
        PP.UI.showSuccess({ title: 'Withdrawal Successful', subtitle: `${PP.fmt(amount)} withdrawn successfully`, meta: { 'New balance': PP.fmt(res?.data?.new_balance || 0) } });
        PP.emit('transactions:changed'); PP.refreshCurrentView();
      } catch (e) { PP.UI.toast('Withdrawal failed', e.message, 'error'); }
      finally { wdBtn.disabled = false; wdBtn.innerHTML = ['Withdraw']; }
    }}, ['Withdraw']);
    modal.footer.appendChild(wdBtn);
    PP.refreshIcons();
  },

  archivePocket(pocket) {
    return PP.UI.confirm(`Archive "${pocket.name}"?`, 'This pocket will be hidden but all transactions and history will be preserved.', { icon: 'archive', iconClass: 'bg-warning', okLabel: 'Archive', okClass: 'btn-warning' }).then(async ok => {
      if (!ok) return false;
      try { await PP.PocketsAPI.archive(pocket.id); PP.UI.toast('Archived', `${pocket.name} has been archived`, 'info'); PP.emit('pockets:changed'); PP.refreshCurrentView(); return true; }
      catch (e) { PP.UI.toast('Error', e.message, 'error'); return false; }
    });
  },

  restorePocket(pocket) {
    return PP.UI.confirm(`Restore "${pocket.name}"?`, 'This pocket will be un-archived and shown in your active pockets.', { icon: 'archive-restore', iconClass: 'bg-success', okLabel: 'Restore', okClass: 'btn-success' }).then(async ok => {
      if (!ok) return false;
      try { await PP.PocketsAPI.restore(pocket.id); PP.UI.toast('Restored', `${pocket.name} has been restored`, 'success'); PP.emit('pockets:changed'); PP.refreshCurrentView(); return true; }
      catch (e) { PP.UI.toast('Error', e.message, 'error'); return false; }
    });
  },

  deletePocket(pocket) {
    return PP.UI.confirm(`Delete "${pocket.name}" permanently?`, pocket.current_balance > 0
      ? `This pocket still has ${PP.fmt(pocket.current_balance)}. Transfer the balance first.`
      : 'All history will be removed and this cannot be undone.',
      { icon: 'trash-2', iconClass: 'bg-danger', okLabel: 'Delete', okClass: 'btn-danger' }).then(async ok => {
      if (!ok) return false;
      try { await PP.PocketsAPI.remove(pocket.id); PP.UI.toast('Deleted', `${pocket.name} has been deleted`, 'info'); PP.emit('pockets:changed'); PP.refreshCurrentView(); return true; }
      catch (e) { PP.UI.toast('Delete failed', e.message, 'error'); return false; }
    });
  },

  async saveDistributionRule(rule = null) {
    const editing = !!rule;
    const pockets = PP.state.pockets?.length ? PP.state.pockets : await PP.PocketsAPI.list({ per_page: 200 }).then(r => r.data.items).catch(() => []);
    let name = rule?.name || ''; let desc = rule?.description || ''; let ruleType = rule?.rule_type || 'percentage';
    let allocations = rule?.allocations ? rule.allocations.map(a => ({ ...a })) : [];
    const modal = PP.UI.modal({ title: editing ? 'Edit Rule' : 'Save Distribution Rule', subtitle: editing ? 'Update your allocation rule' : 'Create a reusable rule for quick income splits', icon: 'bookmark', iconClass: 'bg-accent', size: 'lg' });
    const renderBody = () => {
      const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem' });
      body.appendChild(PP.el('div', { class: 'form-row' }, [
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Rule Name *']),
          (() => { const inp = PP.el('input', { class: 'form-input', placeholder: 'e.g. Monthly Salary Split', value: name }); inp.oninput = () => name = inp.value; return inp; })(),
        ]),
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Allocation Type']),
          (() => {
            const s = PP.el('select', { class: 'form-select' });
            [['percentage', 'Percentage Split'], ['fixed', 'Fixed Amounts']].forEach(o => { const op = PP.el('option', { value: o[0] }, [o[1]]); if (ruleType === o[0]) op.selected = true; s.appendChild(op); });
            s.onchange = () => { ruleType = s.value; allocations = []; renderBody(); };
            return s;
          })(),
        ]),
      ]));
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Description (optional)']),
        (() => { const t = PP.el('textarea', { class: 'form-textarea', rows: 1 }); t.value = desc; t.oninput = () => desc = t.value; return t; })(),
      ]));
      let total = ruleType === 'percentage' ? allocations.reduce((s, a) => s + (a.percentage || 0), 0) : 0;
      body.appendChild(PP.el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:.25rem' }, [
        PP.el('span', { class: 'form-label' }, ['Pocket Allocations']),
        ruleType === 'percentage' && PP.el('span', { class: 'font-semibold mono', style: `color:${Math.abs(total - 100) < .01 ? 'var(--success)' : 'var(--warning)'}` }, [`${total.toFixed(0)}% / 100%`]),
      ]));
      const list = PP.el('div', { style: 'display:flex;flex-direction:column;gap:.4rem;max-height:320px;overflow:auto;padding:.25rem' });
      pockets.filter(p => !p.archived).forEach(p => {
        const curr = allocations.find(a => a.pocket_id == p.id);
        const r = PP.el('div', { style: 'display:grid;grid-template-columns:1fr 110px;gap:.5rem;align-items:center' }, [
          PP.el('div', { style: 'display:flex;align-items:center;gap:.5rem' }, [
            PP.el('div', { style: `width:30px;height:30px;border-radius:8px;background:${p.color};color:white;display:flex;align-items:center;justify-content:center;flex-shrink:0` }, [PP.el('i', { 'data-lucide': p.icon, style: 'width:14px;height:14px' })]),
            PP.el('span', { style: 'font-weight:500' }, [p.name]),
          ]),
        ]);
        const inp = PP.el('input', { class: 'form-input', type: 'number', min: '0', step: ruleType === 'percentage' ? '1' : '0.01', value: curr ? (ruleType === 'percentage' ? curr.percentage : curr.amount) : '', style: 'padding:.5rem;font-size:.85rem;text-align:right' });
        inp.oninput = () => {
          const v = parseFloat(inp.value);
          if (!v || v <= 0) allocations = allocations.filter(a => a.pocket_id != p.id);
          else { let rec = allocations.find(a => a.pocket_id == p.id); if (!rec) { rec = { pocket_id: p.id, pocket_name: p.name }; allocations.push(rec); } if (ruleType === 'percentage') rec.percentage = v; else rec.amount = v; }
          renderBody();
        };
        r.appendChild(inp); list.appendChild(r);
      });
      body.appendChild(list);
      modal.body.innerHTML = ''; modal.body.appendChild(body);
      modal.footer.innerHTML = ''; modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      const saveBtn = PP.el('button', { class: 'btn btn-primary', onclick: async () => {
        if (!name.trim()) return PP.UI.toast('Name required', 'Enter a rule name', 'warning');
        if (!allocations.length) return PP.UI.toast('No allocations', 'Pick at least one pocket', 'warning');
        if (ruleType === 'percentage') { const t = allocations.reduce((s, a) => s + (a.percentage || 0), 0); if (Math.abs(t - 100) > .01) return PP.UI.toast('Must sum to 100%', `Current: ${t.toFixed(0)}%`, 'warning'); }
        try {
          saveBtn.disabled = true; saveBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Saving…'; PP.refreshIcons();
          const payload = { name: name.trim(), rule_type: ruleType, description: desc.trim() || null, allocations };
          const res = editing ? await PP.WalletAPI.updateRule(rule.id, payload) : await PP.WalletAPI.createRule(payload);
          PP.UI.toast('Rule saved', res.message || 'Rule has been stored', 'success'); modal.close(); PP.emit('rules:changed'); PP.refreshCurrentView();
        } catch (e) { PP.UI.toast('Save failed', e.message, 'error'); }
        finally { saveBtn.disabled = false; saveBtn.innerHTML = ['Save Rule']; }
      }}, ['Save Rule']);
      modal.footer.appendChild(saveBtn);
      PP.refreshIcons();
    };
    renderBody();
  },

  verifyEmail() {
    return PP.UI.prompt('Verify Email', 'Enter 6-digit OTP sent to your email').then(async otp => {
      if (!otp) return false;
      try { const res = await PP.Auth.verifyEmail(otp); PP.UI.toast('Email verified', res.message, 'success'); PP.state.user.email_verified = true; PP.refreshUserChrome(); return true; }
      catch (e) { PP.UI.toast('Verification failed', e.message, 'error'); return false; }
    });
  },

  verifyPhone() {
    if (!PP.state.user?.phone) {
      return PP.UI.prompt('Add Phone Number', 'Enter your phone number with country code').then(async phone => {
        if (!phone) return false;
        try {
          await PP.Auth.updateProfile({ phone });
          PP.state.user.phone = phone;
          PP.refreshUserChrome();
        } catch (e) { PP.UI.toast('Error', e.message, 'error'); return false; }
        return PP.Modals.verifyPhone();
      });
    }
    return PP.UI.prompt('Verify Phone', 'Enter 6-digit OTP sent to your phone').then(async otp => {
      if (!otp) return false;
      try {
        const res = await PP.Auth.verifyPhone(otp);
        PP.UI.toast('Phone verified', res.message, 'success');
        PP.state.user.phone_verified = true;
        PP.refreshUserChrome();
        return true;
      } catch (e) { PP.UI.toast('Verification failed', e.message, 'error'); return false; }
    });
  },

  changePin() {
    let step = 1; let oldPin = ''; let pin1 = ''; let pin2 = '';
    const modal = PP.UI.modal({ title: 'Change Transaction PIN', subtitle: 'Enter your current PIN and then a new 4-digit PIN', icon: 'lock', iconClass: 'bg-warning', size: 'sm' });
    const renderBody = () => {
      const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem;align-items:center;padding:1rem 0' });
      body.appendChild(PP.el('div', { class: 'stepper', style: 'justify-content:center' },
        ['Current','New PIN','Confirm'].map((label, i) => {
          const n = i + 1;
          const s = PP.el('div', { class: `step ${step === n ? 'active' : step > n ? 'done' : ''}` }, [
            PP.el('div', { class: 'step-circle' }, [step > n ? PP.el('i', { 'data-lucide': 'check', style: 'width:14px;height:14px' }) : String(n)]),
            PP.el('div', { class: 'step-label' }, [label]),
          ]);
          if (n < 3) s.appendChild(PP.el('div', { class: 'step-line' }));
          return s;
        })
      ));
      const title = step === 1 ? 'Enter current PIN' : (step === 2 ? 'Create new 4-digit PIN' : 'Confirm new PIN');
      body.appendChild(PP.el('div', { class: 'form-label', style: 'font-weight:600;font-size:.9rem' }, [title]));
      const dots = PP.el('div', { class: 'pin-dots', style: 'display:flex;gap:.75rem;margin:.5rem 0 1rem' });
      const target = step === 1 ? 4 : (step === 2 ? 4 : 4);
      const enteredCur = step === 1 ? oldPin : (step === 2 ? pin1 : pin2);
      for (let i = 0; i < target; i++) dots.appendChild(PP.el('div', { class: 'pin-dot' + (enteredCur[i] ? ' filled' : ''), style: `width:14px;height:14px;border-radius:50%;border:2px solid ${enteredCur[i] ? 'var(--accent)' : 'var(--border-strong)'};background:${enteredCur[i] ? 'var(--accent)' : 'transparent'};transition:all .15s ease` }));
      body.appendChild(dots);
      const pad = PP.el('div', { class: 'pin-pad', style: 'display:grid;grid-template-columns:repeat(3,60px);gap:.5rem' });
      const set = (d) => {
        if (step === 1 && oldPin.length < 4) { oldPin += d; if (oldPin.length === 4) { setTimeout(() => { step = 2; renderBody(); }, 180); } }
        else if (step === 2 && pin1.length < 4) { pin1 += d; if (pin1.length === 4) { setTimeout(() => { step = 3; renderBody(); }, 180); } }
        else if (step === 3 && pin2.length < 4) { pin2 += d; if (pin2.length === 4) { setTimeout(async () => {
          if (pin1 !== pin2) { PP.UI.toast('PIN mismatch', 'PINs do not match, please try again', 'error'); pin1 = ''; pin2 = ''; step = 2; renderBody(); return; }
          try {
            const subBtn = modal.footer.querySelector('.btn-warning');
            if (subBtn) { subBtn.disabled = true; subBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i>…'; PP.refreshIcons(); }
            await PP.Auth.changePin(oldPin, pin1);
            PP.UI.toast('PIN changed', 'Your transaction PIN has been updated', 'success');
            modal.close();
            PP.state.user = (await PP.Auth.me()).data.user;
            PP.refreshUserChrome();
          } catch (e) { PP.UI.toast('Change PIN failed', e.message, 'error'); pin1 = ''; pin2 = ''; oldPin = ''; step = 1; renderBody(); }
          finally { const subBtn = modal.footer.querySelector('.btn-warning'); if (subBtn) { subBtn.disabled = false; subBtn.innerHTML = ['Change PIN']; } }
        }, 220); } }
        renderBody();
      };
      [1,2,3,4,5,6,7,8,9].forEach(d => pad.appendChild(PP.el('button', { class: 'btn btn-ghost', style: 'width:60px;height:60px;font-size:1.25rem;font-weight:700', onclick: () => set(String(d)) }, [String(d)])));
      pad.appendChild(PP.el('button', { class: 'btn btn-outline', style: 'width:60px;height:60px;font-weight:600', onclick: () => {
        if (step === 1 && oldPin.length > 0) oldPin = oldPin.slice(0, -1);
        else if (step === 2 && pin1.length > 0) pin1 = pin1.slice(0, -1);
        else if (step === 3 && pin2.length > 0) pin2 = pin2.slice(0, -1);
        renderBody();
      } }, [PP.el('i', { 'data-lucide': 'delete', style: 'width:18px;height:18px' })]));
      pad.appendChild(PP.el('button', { class: 'btn btn-ghost', style: 'width:60px;height:60px;font-size:1.25rem;font-weight:700', onclick: () => set('0') }, ['0']));
      pad.appendChild(PP.el('button', { class: 'btn btn-outline', style: 'width:60px;height:60px;font-weight:600;color:var(--danger)', onclick: () => modal.close() }, [PP.el('i', { 'data-lucide': 'x', style: 'width:18px;height:18px' })]));
      body.appendChild(pad);
      modal.body.innerHTML = ''; modal.body.appendChild(body);
      modal.footer.innerHTML = '';
      if (step > 1) modal.footer.appendChild(PP.el('button', { class: 'btn btn-outline', onclick: () => { if (step === 3) pin2 = ''; else if (step === 2) pin1 = ''; step--; renderBody(); } }, ['Back']));
      modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      const go = PP.el('button', { class: 'btn btn-warning', onclick: async () => {
        if (step === 1 && oldPin.length === 4) { step = 2; renderBody(); }
        else if (step === 2 && pin1.length === 4) { step = 3; renderBody(); }
        else if (step === 3 && pin2.length === 4) {
          if (pin1 !== pin2) { PP.UI.toast('PIN mismatch', 'PINs do not match', 'error'); pin1 = ''; pin2 = ''; step = 2; renderBody(); return; }
          try {
            go.disabled = true; go.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i>…'; PP.refreshIcons();
            await PP.Auth.changePin(oldPin, pin1);
            PP.UI.toast('PIN changed', 'PIN updated successfully', 'success'); modal.close();
            PP.state.user = (await PP.Auth.me()).data.user; PP.refreshUserChrome();
          } catch (e) { PP.UI.toast('Change PIN failed', e.message, 'error'); pin1 = ''; pin2 = ''; oldPin = ''; step = 1; renderBody(); }
          finally { go.disabled = false; go.innerHTML = ['Change PIN']; }
        } else PP.UI.toast('Enter PIN', 'Please enter a full 4-digit PIN', 'warning');
      } }, ['Change PIN']);
      modal.footer.appendChild(go);
      PP.refreshIcons();
    };
    renderBody();
  },

  changePassword() {
    const modal = PP.UI.modal({ title: 'Change Password', subtitle: 'Update your account password', icon: 'key-round', iconClass: 'bg-info', size: 'md' });
    const body = PP.el('form', { class: 'auth-form', style: 'display:flex;flex-direction:column;gap:1rem', onsubmit: async (e) => {
      e.preventDefault();
      const fd = new FormData(body);
      const old = fd.get('old_password') || '';
      const np = fd.get('new_password') || '';
      const cp = fd.get('confirm_password') || '';
      if (!old || !np || np.length < 8) return PP.UI.toast('Invalid password', 'New password must be at least 8 characters', 'warning');
      if (np !== cp) return PP.UI.toast('Mismatch', 'New passwords do not match', 'warning');
      const sub = modal.footer.querySelector('.btn-primary');
      try {
        sub.disabled = true; sub.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Updating…'; PP.refreshIcons();
        await PP.Auth.updateProfile({ old_password: old, password: np });
        PP.UI.toast('Password changed', 'Your password has been updated', 'success');
        modal.close();
      } catch (e) { PP.UI.toast('Change failed', e.message, 'error'); }
      finally { sub.disabled = false; sub.innerHTML = ['Update Password']; }
    } });
    body.innerHTML = `
      <div class="form-group"><label class="form-label">Current Password</label><input class="form-input" name="old_password" type="password" placeholder="••••••••" required /></div>
      <div class="form-group"><label class="form-label">New Password (min 8 chars)</label><input class="form-input" name="new_password" type="password" minlength="8" placeholder="••••••••" required /></div>
      <div class="form-group"><label class="form-label">Confirm New Password</label><input class="form-input" name="confirm_password" type="password" minlength="8" placeholder="••••••••" required /></div>`;
    modal.body.innerHTML = ''; modal.body.appendChild(body);
    modal.footer.innerHTML = '';
    modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', type: 'button', onclick: () => modal.close() }, ['Cancel']));
    modal.footer.appendChild(PP.el('button', { class: 'btn btn-primary', type: 'submit', form: body.getAttribute('class')?.includes('auth-form') ? null : null }, ['Update Password']));
    const sb = modal.footer.querySelector('.btn-primary'); sb.onclick = () => body.requestSubmit();
    PP.refreshIcons();
  },

  pocketActions(pocket) {
    if (!pocket) return;
    const modal = PP.UI.modal({ title: pocket.name, subtitle: `Balance: ${PP.fmt(pocket.current_balance)}`, icon: pocket.icon || 'wallet', iconClass: 'bg-accent', size: 'sm' });
    const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:.5rem' });
    const makeBtn = (label, icon, cls, fn, danger = false) => PP.el('button', { class: `btn ${cls}`, style: 'justify-content:flex-start;gap:.75rem;padding:.85rem 1rem', onclick: async () => {
      try { await fn(); modal.close(); } catch {}
    } }, [PP.el('i', { 'data-lucide': icon, style: 'width:16px;height:16px' }), label]);
    body.appendChild(makeBtn('Edit Pocket', 'pencil', 'btn-outline', () => PP.Modals.createPocket(pocket)));
    body.appendChild(makeBtn('Deposit Money', 'arrow-down-left', 'btn-outline', () => PP.Modals.addIncomeForPocket(pocket.id)));
    body.appendChild(makeBtn('Pay / Expense', 'arrow-up-right', 'btn-outline', () => PP.Modals.addExpenseForPocket(pocket.id)));
    if (!pocket.archived) body.appendChild(makeBtn('Archive Pocket', 'archive', 'btn-outline btn-warning', () => PP.Modals.archivePocket(pocket)));
    else body.appendChild(makeBtn('Restore Pocket', 'archive-restore', 'btn-outline btn-success', () => PP.Modals.restorePocket(pocket)));
    body.appendChild(makeBtn('Delete Pocket', 'trash-2', 'btn-outline btn-danger', () => PP.Modals.deletePocket(pocket), true));
    modal.body.innerHTML = ''; modal.body.appendChild(body);
    modal.footer.innerHTML = '';
    modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Close']));
    PP.refreshIcons();
  },

  addIncomeForPocket(pocketId) {
    return PP.Modals.addIncome({ singlePocketId: pocketId, strategy: 'single' });
  },

  addExpenseForPocket(pocketId) {
    return PP.Modals.addExpense(pocketId);
  },

  createBudget(existing = null) {
    const editing = !!existing;
    const pockets = PP.state.pockets?.length ? PP.state.pockets : [];
    let name = existing?.name || '';
    let limit = existing?.limit_amount || 0;
    let category = existing?.category || '';
    let pocket_id = existing?.pocket_id || '';
    let period = existing?.period || 'monthly';
    const modal = PP.UI.modal({ title: editing ? 'Edit Budget' : 'Create Budget', subtitle: editing ? 'Update your budget' : 'Set a spending limit to stay on track', icon: 'target', iconClass: 'bg-info', size: 'md' });
    const renderBody = () => {
      const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1rem' });
      body.appendChild(PP.el('div', { class: 'form-row' }, [
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Budget Name *']),
          (() => { const i = PP.el('input', { class: 'form-input', placeholder: 'e.g. Grocery Budget', value: name }); i.oninput = () => name = i.value; return i; })(),
        ]),
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Period']),
          (() => {
            const s = PP.el('select', { class: 'form-select' });
            [['weekly','Weekly'],['monthly','Monthly'],['quarterly','Quarterly'],['yearly','Yearly']].forEach(o => {
              const op = PP.el('option', { value: o[0] }, [o[1]]); if (period === o[0]) op.selected = true; s.appendChild(op);
            });
            s.onchange = () => period = s.value; return s;
          })(),
        ]),
      ]));
      body.appendChild(PP.el('div', { class: 'form-row' }, [
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Limit Amount *']),
          (() => { const i = PP.el('input', { class: 'form-input', type: 'number', min: '1', step: '1', placeholder: '0', value: limit || '' }); i.oninput = () => limit = parseFloat(i.value) || 0; return i; })(),
        ]),
        PP.el('div', { class: 'form-group' }, [
          PP.el('label', { class: 'form-label' }, ['Apply to Pocket (optional)']),
          (() => {
            const s = PP.el('select', { class: 'form-select' });
            s.appendChild(PP.el('option', { value: '' }, ['— All pockets —']));
            pockets.filter(p => !p.archived).forEach(p => { const op = PP.el('option', { value: p.id }, [`${p.name} (${PP.fmt(p.current_balance)})`]); if (pocket_id == p.id) op.selected = true; s.appendChild(op); });
            s.onchange = () => pocket_id = s.value ? parseInt(s.value) : ''; return s;
          })(),
        ]),
      ]));
      const cats = PP.state.categories?.length ? PP.state.categories : ['Food & Dining','Shopping','Transportation','Entertainment','Bills & Utilities','Healthcare','Education','Travel','Other'];
      body.appendChild(PP.el('div', { class: 'form-group' }, [
        PP.el('label', { class: 'form-label' }, ['Category (optional, leave blank for all)']),
        (() => {
          const s = PP.el('select', { class: 'form-select' });
          s.appendChild(PP.el('option', { value: '' }, ['— All categories —']));
          cats.forEach(c => { const op = PP.el('option', { value: c }, [c]); if (category === c) op.selected = true; s.appendChild(op); });
          s.onchange = () => category = s.value; return s;
        })(),
      ]));
      modal.body.innerHTML = ''; modal.body.appendChild(body);
      modal.footer.innerHTML = '';
      modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
      const save = PP.el('button', { class: 'btn btn-primary', onclick: async () => {
        if (!name.trim()) return PP.UI.toast('Name required', 'Please enter a budget name', 'warning');
        if (!(limit > 0)) return PP.UI.toast('Invalid limit', 'Please enter a valid limit amount', 'warning');
        try {
          save.disabled = true; save.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Saving…'; PP.refreshIcons();
          let startDate, endDate;
          if (editing && existing?.start_date && existing?.end_date) {
            startDate = existing.start_date;
            endDate = existing.end_date;
          } else {
            const today = new Date();
            const end = new Date(today);
            if (period === 'weekly') end.setDate(today.getDate() + 7);
            else if (period === 'quarterly') end.setMonth(today.getMonth() + 3);
            else if (period === 'yearly') end.setFullYear(today.getFullYear() + 1);
            else end.setMonth(today.getMonth() + 1);
            startDate = today.toISOString().split('T')[0];
            endDate = end.toISOString().split('T')[0];
          }
          const payload = {
            name: name.trim(), limit_amount: Number(limit), period,
            category: category || null, pocket_id: pocket_id || null,
            start_date: startDate, end_date: endDate, is_active: true, repeat: true,
          };
          if (editing) await PP.AnalyticsAPI.updateBudget(existing.id, payload);
          else await PP.AnalyticsAPI.createBudget(payload);
          PP.UI.toast('Budget saved', editing ? 'Budget has been updated' : 'Budget has been created', 'success');
          modal.close(); PP.refreshCurrentView();
        } catch (e) { PP.UI.toast('Save failed', e.message, 'error'); }
        finally { save.disabled = false; save.innerHTML = [editing ? 'Update Budget' : 'Create Budget']; }
      }}, [editing ? 'Update Budget' : 'Create Budget']);
      modal.footer.appendChild(save);
      PP.refreshIcons();
    };
    renderBody();
  },

  transactionDetail(tx) {
    if (!tx) return;
    const modal = PP.UI.modal({ title: 'Transaction Details', subtitle: `Transaction #${tx.transaction_id || tx.id}`, icon: 'receipt', iconClass: 'bg-accent', size: 'md' });
    const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:.75rem' });
    const isExp = tx.type === 'expense' || tx.amount < 0;
    const color = isExp ? 'var(--danger)' : (tx.type === 'income' || tx.type === 'topup' ? 'var(--success)' : 'var(--accent)');
    body.appendChild(PP.el('div', { class: 'glass-card', style: `padding:1.5rem;text-align:center;border:1px solid ${color}33` }, [
      PP.el('div', { style: `font-size:.8rem;text-transform:uppercase;letter-spacing:.1em;font-weight:700;color:${color};margin-bottom:.5rem` }, [tx.type || 'Transaction']),
      PP.el('div', { style: `font-family:var(--font-display);font-size:2.25rem;font-weight:900;color:${color}` }, [
        `${isExp ? '-' : '+'}${PP.fmt(Math.abs(tx.amount || 0))}`,
      ]),
      tx.status && PP.el('div', { class: `chip ${tx.status === 'completed' ? 'success' : 'warning'}`, style: 'margin-top:.5rem' }, [tx.status.toUpperCase()]),
    ]));
    const row = (k, v, copy = false) => PP.el('div', { class: 'setting-row', style: 'display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:.65rem 0;border-bottom:1px solid var(--border)' }, [
      PP.el('span', { class: 'text-muted', style: 'font-size:.85rem;font-weight:500' }, [k]),
      PP.el('div', { style: 'display:flex;align-items:center;gap:.4rem' }, [
        PP.el('span', { style: 'font-weight:600;font-size:.9rem' }, [v || '—']),
        copy && PP.el('button', { class: 'btn-icon-sm btn btn-ghost', style: 'padding:0;width:28px;height:28px', onclick: () => { navigator.clipboard?.writeText(v); PP.UI.toast('Copied', k + ' copied', 'success'); } }, [PP.el('i', { 'data-lucide': 'copy', style: 'width:13px;height:13px' })]),
      ]),
    ]);
    body.appendChild(row('Date & Time', PP.formatDateTime(tx.created_at || tx.date)));
    body.appendChild(row('Category', tx.category || '—'));
    if (tx.merchant) body.appendChild(row('Merchant', tx.merchant));
    if (tx.from_pocket_name || tx.from_pocket_id) body.appendChild(row('From', tx.from_pocket_name || `Pocket #${tx.from_pocket_id}`));
    if (tx.to_pocket_name || tx.to_pocket_id) body.appendChild(row('To', tx.to_pocket_name || `Pocket #${tx.to_pocket_id}`));
    if (tx.payment_method) body.appendChild(row('Method', tx.payment_method));
    if (tx.description || tx.notes) body.appendChild(row('Notes', tx.description || tx.notes));
    body.appendChild(row('Transaction ID', tx.transaction_id || tx.id, true));
    modal.body.innerHTML = ''; modal.body.appendChild(body);
    modal.footer.innerHTML = '';
    if (tx.status === 'completed' && (tx.type === 'expense' || tx.type === 'transfer')) {
      const refBtn = PP.el('button', { class: 'btn btn-outline', onclick: async () => {
        try {
          const pin = await PP.UI.pinPrompt({ title: 'Confirm Refund', subtitle: 'Enter transaction PIN to proceed' });
          if (!pin) return;
          refBtn.disabled = true; refBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i>…'; PP.refreshIcons();
          await PP.TxAPI.refund(tx.id, pin);
          PP.UI.toast('Refunded', 'Transaction has been refunded', 'success');
          modal.close(); PP.refreshCurrentView();
        } catch (e) { PP.UI.toast('Refund failed', e.message, 'error'); }
        finally { refBtn.disabled = false; refBtn.innerHTML = [PP.el('i', { 'data-lucide': 'undo-2', style: 'width:16px;height:16px' }), 'Refund']; }
      }}, [PP.el('i', { 'data-lucide': 'undo-2', style: 'width:16px;height:16px' }), 'Refund']);
      modal.footer.appendChild(refBtn);
    }
    modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Close']));
    PP.refreshIcons();
  },

  reorderPockets() {
    const pockets = (PP.state.pockets || []).filter(p => !p.archived).slice().sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
    if (!pockets.length) return PP.UI.toast('Nothing to sort', 'Create some pockets first', 'info');
    const modal = PP.UI.modal({ title: 'Reorder Pockets', subtitle: 'Drag and drop to reorder', icon: 'arrow-up-down', iconClass: 'bg-accent', size: 'md' });
    let order = pockets.map(p => p.id);
    const body = PP.el('div', { style: 'display:flex;flex-direction:column;gap:.5rem;max-height:50vh;overflow:auto;padding:.25rem' });
    const render = () => {
      body.innerHTML = '';
      order.forEach((pid, idx) => {
        const p = pockets.find(pp => pp.id === pid) || {};
        const row = PP.el('div', { class: 'glass-card', draggable: 'true', style: `padding:.75rem 1rem;display:flex;align-items:center;gap:.75rem;cursor:grab;border-left:4px solid ${p.color || 'var(--accent)'}` }, [
          PP.el('i', { 'data-lucide': 'grip-vertical', style: 'color:var(--text-dim);cursor:grab' }),
          PP.el('div', { style: `width:32px;height:32px;border-radius:8px;background:${p.color || '#6366f1'};color:white;display:flex;align-items:center;justify-content:center;flex-shrink:0` }, [PP.el('i', { 'data-lucide': p.icon || 'wallet', style: 'width:14px;height:14px' })]),
          PP.el('span', { style: 'font-weight:600;flex:1' }, [p.name || `Pocket ${pid}`]),
          PP.el('span', { class: 'text-dim', style: 'font-family:var(--font-mono);font-size:.8rem' }, [`#${idx + 1}`]),
        ]);
        row.addEventListener('dragstart', (e) => { row.style.opacity = '.5'; e.dataTransfer.setData('text/plain', String(pid)); e.dataTransfer.effectAllowed = 'move'; });
        row.addEventListener('dragend', () => { row.style.opacity = '1'; });
        row.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; row.style.background = 'var(--hover-bg)'; });
        row.addEventListener('dragleave', () => { row.style.background = ''; });
        row.addEventListener('drop', (e) => {
          e.preventDefault(); row.style.background = '';
          const draggedId = parseInt(e.dataTransfer.getData('text/plain'));
          if (isNaN(draggedId) || draggedId === pid) return;
          const from = order.indexOf(draggedId); const to = order.indexOf(pid);
          if (from < 0 || to < 0) return;
          order.splice(from, 1); order.splice(to, 0, draggedId);
          render();
        });
        body.appendChild(row);
      });
      PP.refreshIcons();
    };
    render();
    modal.body.innerHTML = ''; modal.body.appendChild(body);
    modal.footer.innerHTML = '';
    modal.footer.appendChild(PP.el('button', { class: 'btn btn-ghost', onclick: () => modal.close() }, ['Cancel']));
    const saveBtn = PP.el('button', { class: 'btn btn-primary', onclick: async () => {
      try {
        saveBtn.disabled = true; saveBtn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Saving…'; PP.refreshIcons();
        await PP.PocketsAPI.reorder(order);
        PP.UI.toast('Saved', 'Pocket order updated', 'success');
        modal.close(); PP.refreshCurrentView();
      } catch (e) { PP.UI.toast('Save failed', e.message, 'error'); }
      finally { saveBtn.disabled = false; saveBtn.innerHTML = ['Save Order']; }
    }}, ['Save Order']);
    modal.footer.appendChild(saveBtn);
    PP.refreshIcons();
  },

};

// Backward compatibility aliases
PP.Modals.setupPIN = PP.Modals.setupPin;
PP.Modals.changePIN = PP.Modals.changePin;
PP.Modals.saveRule = PP.Modals.saveDistributionRule;

PP.UI.genericModal = PP.UI.modal;
