// ========== Dashboard View ==========
PP.Dashboard = {
  async render(container, params = {}) {
    container.innerHTML = `<div class="stagger" style="display:flex;flex-direction:column;gap:1.5rem">
      ${PP.Skeletons.card(4).outerHTML}
      ${PP.Skeletons.card(5).outerHTML}
    </div>`;
    PP.refreshIcons();
    let data, analytics, txs, insights, budgets;
    try { [data, analytics, txs, insights, budgets] = await Promise.all([
      PP.MiscAPI.dashboard(),
      PP.AnalyticsAPI.overview(),
      PP.TxAPI.list({ per_page: 8 }),
      PP.AnalyticsAPI.insights().catch(() => null),
      PP.WalletAPI.rules().catch(() => null),
    ]); } catch (e) { return PP.UI.toast('Error loading dashboard', e.message, 'error'); }

    const u = data?.data?.user || PP.state.user || {};
    const b = data?.data?.balances || {};
    const w = analytics?.data?.weekly || {};
    const m = analytics?.data?.monthly || {};
    const mc = analytics?.data?.month_over_month || {};
    const pockets = data?.data?.pockets || [];
    const transactions = txs?.data?.items || [];
    PP.state.distributionRules = budgets?.data?.rules || PP.state.distributionRules || [];

    const savedThisMonth = m.income - m.expense;

    container.innerHTML = '';
    const wrap = PP.el('div', { style: 'display:flex;flex-direction:column;gap:1.5rem' });
    container.appendChild(wrap);

    // ---------- Header ----------
    const greet = (() => {
      const h = new Date().getHours();
      if (h < 12) return 'Good morning';
      if (h < 18) return 'Good afternoon';
      return 'Good evening';
    })();
    wrap.appendChild(PP.el('div', { class: 'page-header' }, [
      PP.el('div', {}, [
        PP.el('p', { class: 'page-eyebrow' }, ['Dashboard']),
        PP.el('h2', { class: 'page-title' }, [`${greet}, ${(u.full_name || 'there').split(' ')[0]} 👋`]),
        PP.el('p', { class: 'page-sub' }, [`Ready to hit your savings goals today?`]),
      ]),
      PP.el('div', { class: 'page-actions' }, [
        PP.el('button', {
          class: 'btn btn-ghost',
          onclick: () => PP.navigate('analytics'),
        }, [PP.el('i', { 'data-lucide': 'bar-chart-3' }), 'View Reports']),
        PP.el('button', {
          class: 'btn btn-primary',
          onclick: () => PP.Modals.addIncome(),
        }, [PP.el('i', { 'data-lucide': 'plus' }), 'Add Income']),
      ]),
    ]));

    // ---------- Balance Card & Quick Actions ----------
    const balanceCard = PP.el('div', { class: 'balance-card' }, [
      PP.el('div', { class: 'balance-card-inner' }, [
        PP.el('div', {}, [
          PP.el('div', { class: 'balance-label' }, [PP.el('i', { 'data-lucide': 'wallet' }), 'Total Net Worth']),
          PP.el('div', { class: 'balance-amount' }, [PP.el('span', { class: 'symbol' }, ['₹']), PP.fmt((b.total || 0)).replace('₹', '')]),
          PP.el('div', { class: 'balance-sub' }, [
            PP.el('div', {}, [PP.el('i', { 'data-lucide': 'folders' }), `${pockets.length} Pockets`]),
            PP.el('div', {}, [PP.el('i', { 'data-lucide': 'wallet' }), `Wallet: ${PP.fmt(b.wallet || 0)}`]),
            PP.el('div', {}, [PP.el('i', { 'data-lucide': 'lock' }), `PIN: ${u.has_transaction_pin ? 'Active' : 'Not set'}`]),
          ]),
        ]),
        PP.el('div', { class: 'balance-actions' }, [
          PP.el('button', { class: 'balance-action', onclick: () => PP.Modals.addIncome() }, [
            PP.el('div', { class: 'balance-action-icon income' }, [PP.el('i', { 'data-lucide': 'arrow-down-left' })]),
            PP.el('div', { class: 'balance-action-label' }, [PP.el('div', {}, ['Add Income']), PP.el('div', {}, ['Credits to pockets'])]),
          ]),
          PP.el('button', { class: 'balance-action', onclick: () => PP.Modals.addExpense() }, [
            PP.el('div', { class: 'balance-action-icon expense' }, [PP.el('i', { 'data-lucide': 'arrow-up-right' })]),
            PP.el('div', { class: 'balance-action-label' }, [PP.el('div', {}, ['Make Payment']), PP.el('div', {}, ['PIN protected'])]),
          ]),
          PP.el('button', { class: 'balance-action', onclick: () => PP.Modals.transfer() }, [
            PP.el('div', { class: 'balance-action-icon transfer' }, [PP.el('i', { 'data-lucide': 'refresh-ccw' })]),
            PP.el('div', { class: 'balance-action-label' }, [PP.el('div', {}, ['Transfer']), PP.el('div', {}, ['Between pockets'])]),
          ]),
          PP.el('button', { class: 'balance-action', onclick: () => PP.navigate('wallet') }, [
            PP.el('div', { class: 'balance-action-icon wallet' }, [PP.el('i', { 'data-lucide': 'qr-code' })]),
            PP.el('div', { class: 'balance-action-label' }, [PP.el('div', {}, ['Wallet QR']), PP.el('div', {}, ['Virtual UPI ID'])]),
          ]),
        ]),
      ]),
    ]);

    const statCards = PP.el('div', { class: 'stats-grid stagger' });
    const stats = [
      { label: 'This Month Income', value: PP.fmt(m.income || 0), icon: 'trending-up', cls: 'income', change: mc.income_change_pct, up: mc.income_increased },
      { label: 'This Month Spent', value: PP.fmt(m.expense || 0), icon: 'credit-card', cls: 'expense', change: mc.expense_change_pct, up: !mc.expense_increased, invert: true },
      { label: 'Net Saved (MoM)', value: PP.fmt(savedThisMonth), icon: 'piggy-bank', cls: 'savings', change: mc.savings_change_pct, up: mc.savings_increased },
      { label: 'Savings Rate', value: `${m.savings_rate || 0}%`, icon: 'target', cls: 'pockets', change: m.savings_rate, up: (m.savings_rate || 0) >= 20 },
    ];
    stats.forEach(s => {
      const delta = s.change == null ? '—' : `${Math.abs(s.change)}% ${s.up ? '↑' : '↓'}`;
      const cls = s.invert ? (s.up ? 'up' : 'down') : (s.up ? 'up' : 'down');
      statCards.appendChild(PP.el('div', { class: 'stat-card glass-card' }, [
        PP.el('div', { class: `stat-icon ${s.cls}` }, [PP.el('i', { 'data-lucide': s.icon })]),
        PP.el('div', { class: 'stat-label' }, [s.label]),
        PP.el('div', { class: 'stat-value' }, [s.value]),
        PP.el('div', { class: `stat-change ${cls}` }, [
          PP.el('i', { 'data-lucide': s.up ? 'trending-up' : 'trending-down' }),
          delta,
          PP.el('span', { style: 'color:var(--text-dim);margin-left:.25rem;font-weight:400' }, ['vs last month']),
        ]),
      ]));
    });

    wrap.appendChild(PP.el('div', { class: 'two-col-grid' }, [
      balanceCard, statCards,
    ]));

    // ---------- Insights strip ----------
    const inList = insights?.data?.insights?.slice(0, 4) || [];
    if (inList.length) {
      const inWrap = PP.el('div', { class: 'insights-grid stagger' });
      inList.forEach(ins => {
        const card = PP.el('div', { class: `insight-card ${ins.priority || ''}` }, [
          PP.el('div', { class: 'insight-top' }, [
            PP.el('div', { class: 'insight-icon' }, [PP.el('i', { 'data-lucide': PP.insightIcon(ins) })]),
            PP.el('span', { class: 'insight-priority' }, [ins.priority || 'info']),
          ]),
          PP.el('h4', {}, [ins.title]),
          PP.el('p', {}, [ins.message]),
        ]);
        inWrap.appendChild(card);
      });
      wrap.appendChild(PP.el('div', { class: 'section-card' }, [
        PP.el('div', { class: 'section-title' }, [
          PP.el('h3', {}, [PP.el('i', { 'data-lucide': 'sparkles', style: 'display:inline;margin-right:.5rem;color:var(--accent-3)' }), 'Smart Insights']),
          PP.el('button', { onclick: () => PP.navigate('analytics') }, ['See all', PP.el('i', { 'data-lucide': 'arrow-right' })]),
        ]),
        inWrap,
      ]));
    }

    // ---------- Pockets + Recent ----------
    const main2Col = PP.el('div', { class: 'two-col-grid' });

    // Pockets card
    const pocketsWrap = PP.el('div', { class: 'section-card' });
    pocketsWrap.appendChild(PP.el('div', { class: 'section-title' }, [
      PP.el('h3', {}, [PP.el('i', { 'data-lucide': 'wallet-cards', style: 'display:inline;margin-right:.5rem;color:var(--accent)' }), 'Your Pockets']),
      PP.el('button', { onclick: () => PP.navigate('pockets') }, ['Manage', PP.el('i', { 'data-lucide': 'arrow-right' })]),
    ]));
    if (!pockets.length) {
      pocketsWrap.appendChild(PP.el('div', { class: 'empty-state' }, [
        PP.el('div', { class: 'empty-icon' }, [PP.el('i', { 'data-lucide': 'folder-open' })]),
        PP.el('h3', {}, ['No pockets yet']),
        PP.el('p', {}, ['Create unlimited custom pockets to organize every rupee.']),
        PP.el('button', { class: 'btn btn-primary btn-sm', onclick: () => PP.Modals.createPocket(), style: 'margin-top:1rem' },
          [PP.el('i', { 'data-lucide': 'plus' }), 'Create First Pocket']),
      ]));
    } else {
      const pgrid = PP.el('div', { class: 'pockets-grid stagger' });
      pockets.slice(0, 6).forEach(p => pgrid.appendChild(PP.Dashboard.renderPocketCard(p)));
      pgrid.appendChild(PP.el('div', { class: 'add-pocket-card', onclick: () => PP.Modals.createPocket() }, [
        PP.el('div', { class: 'add-pocket-icon' }, [PP.el('i', { 'data-lucide': 'plus' })]),
        PP.el('span', {}, ['Add Pocket']),
      ]));
      pocketsWrap.appendChild(pgrid);
    }

    // Recent transactions
    const recentWrap = PP.el('div', { class: 'section-card' });
    recentWrap.appendChild(PP.el('div', { class: 'section-title' }, [
      PP.el('h3', {}, [PP.el('i', { 'data-lucide': 'arrow-left-right', style: 'display:inline;margin-right:.5rem;color:var(--accent)' }), 'Recent Transactions']),
      PP.el('button', { onclick: () => PP.navigate('transactions') }, ['View all', PP.el('i', { 'data-lucide': 'arrow-right' })]),
    ]));
    if (!transactions.length) {
      recentWrap.appendChild(PP.el('div', { class: 'empty-state' }, [
        PP.el('div', { class: 'empty-icon' }, [PP.el('i', { 'data-lucide': 'receipt' })]),
        PP.el('h3', {}, ['No transactions yet']),
        PP.el('p', {}, ['Track every payment and deposit right here.']),
      ]));
    } else {
      const tlist = PP.el('div', { class: 'tx-list' });
      const byDay = PP.Transactions.groupByDay(transactions);
      Object.entries(byDay).forEach(([day, items]) => {
        tlist.appendChild(PP.el('div', { class: 'tx-day-header' }, [day]));
        items.forEach(t => tlist.appendChild(PP.Transactions.renderRow(t)));
      });
      recentWrap.appendChild(tlist);
    }

    main2Col.append(pocketsWrap, recentWrap);
    wrap.appendChild(main2Col);

    // ---------- Analytics row: by category + daily ----------
    const catP = PP.AnalyticsAPI.spendingByCategory(1);
    const dailyP = PP.AnalyticsAPI.dailyTrend(14);
    Promise.all([catP, dailyP]).then(([cat, daily]) => {
      const analRow = PP.el('div', { class: 'two-col-grid' });

      const byCatCard = PP.el('div', { class: 'section-card' });
      byCatCard.appendChild(PP.el('div', { class: 'section-title' }, [
        PP.el('h3', {}, [PP.el('i', { 'data-lucide': 'pie-chart', style: 'display:inline;margin-right:.5rem;color:var(--chart-2)' }), 'Spending by Category']),
        PP.el('span', { class: 'chip' }, ['This month']),
      ]));
      const catInner = PP.el('div', { style: 'display:grid;grid-template-columns:1fr 1.3fr;gap:1.5rem;align-items:center' });
      const donutSegs = (cat?.data?.categories || []).slice(0, 6).map((c, i) => ({
        label: c.category, value: c.amount, color: `var(--chart-${(i % 6) + 1})`,
      }));
      const donutWrap = PP.el('div');
      PP.Charts.donut(donutWrap, donutSegs, 'Spent', 'this month');
      const legend = PP.el('div');
      PP.Charts.breakdown(legend, (cat?.data?.categories || []).slice(0, 6).map((c, i) => ({
        label: c.category, value: c.amount, color: `var(--chart-${(i % 6) + 1})`,
        icon: PP.Transactions.categoryIcon(c.category),
        iconColor: getComputedStyle(document.documentElement).getPropertyValue(`--chart-${(i % 6) + 1}`).trim() || '#6366f1',
      })), { showPct: true });
      catInner.append(donutWrap, legend);
      byCatCard.appendChild(catInner);

      const dailyCard = PP.el('div', { class: 'section-card' });
      dailyCard.appendChild(PP.el('div', { class: 'section-title' }, [
        PP.el('h3', {}, [PP.el('i', { 'data-lucide': 'activity', style: 'display:inline;margin-right:.5rem;color:var(--success)' }), 'Daily Cash Flow']),
        PP.el('span', { class: 'chip' }, ['Last 14 days']),
      ]));
      const areaWrap = PP.el('div', { style: 'margin-bottom:1rem' });
      const points = (daily?.data?.daily || []).map(d => ({ label: d.day_name, value: d.income - d.expense }));
      PP.Charts.area(areaWrap, points);
      const legend2 = PP.el('div', { class: 'chart-legend', style: 'justify-content:space-between' });
      legend2.appendChild(PP.el('div', { class: 'legend-item' }, [PP.el('div', { class: 'legend-dot', style: 'background:var(--success)' }), PP.el('span', {}, ['Net flow'])]));
      dailyCard.append(areaWrap, legend2);

      analRow.append(byCatCard, dailyCard);
      wrap.appendChild(analRow);
      PP.refreshIcons();
    }).catch(e => console.warn(e));
  },

  renderPocketCard(p) {
    const vars = PP.UI.pocketStyleVars(p);
    const usage = p.budget_usage_percent || 0;
    const statusChip = usage >= 100 ? 'danger' : usage >= 75 ? 'warning' : null;
    const card = PP.el('div', {
      class: 'pocket-card glass-card',
      style: Object.entries(vars).map(([k, v]) => `${k}:${v}`).join(';'),
      onclick: () => PP.Pockets.openDetail(p.id),
    });
    card.innerHTML = `
      <div class="pocket-card-bg"></div>
      <div class="pocket-card-inner">
        <div class="pocket-card-top">
          <div class="pocket-icon-wrap"><i data-lucide="${p.icon || 'wallet'}"></i></div>
          <button class="pocket-menu-btn" data-id="${p.id}" aria-label="Pocket menu"><i data-lucide="more-horizontal"></i></button>
        </div>
        <div class="pocket-card-name">${p.name}</div>
        ${p.description ? `<div class="pocket-card-desc">${p.description.slice(0, 50)}</div>` : ''}
        <div class="pocket-card-balance">
          <div class="pocket-balance-label">Balance</div>
          <div class="pocket-balance-value">${PP.fmt(p.current_balance)}</div>
        </div>
        ${(p.monthly_limit || p.budget_amount) ? `
          <div class="pocket-progress"><div class="pocket-progress-fill" style="width:${Math.min(100, usage)}%"></div></div>
          <div class="pocket-meta">
            <span>${statusChip ? `<span class="chip ${statusChip}" style="padding:1px 7px">${usage.toFixed(0)}%</span>` : `${usage.toFixed(0)}% used`}</span>
            <span>${(p.monthly_limit ? PP.fmt(p.monthly_limit) : PP.fmt(p.budget_amount))} limit</span>
          </div>` : ''}
      </div>`;
    setTimeout(() => {
      const btn = card.querySelector('.pocket-menu-btn');
      if (btn) btn.addEventListener('click', (ev) => { ev.stopPropagation(); PP.Modals.pocketActions(p); });
    }, 0);
    return card;
  },
};

PP.insightIcon = (ins) => {
  const t = ins.type || '';
  if (t.includes('budget')) return 'alert-triangle';
  if (t.includes('spike')) return 'trending-up';
  if (t.includes('drop')) return 'trending-down';
  if (t.includes('saving')) return 'piggy-bank';
  if (t.includes('top')) return 'star';
  return 'lightbulb';
};
