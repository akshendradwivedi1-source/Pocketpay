// ========== API Wrapper Layer ==========
PP.API = {
  async request(url, opts = {}) {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
      credentials: 'same-origin',
      ...opts,
      body: opts.body ? (typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body)) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch {}
    if (!res.ok) {
      const err = new Error(data?.message || `HTTP ${res.status}`);
      err.status = res.status;
      err.data = data || {};
      throw err;
    }
    return data;
  },
  get(u, qs) {
    const url = qs ? `${u}?${new URLSearchParams(qs).toString()}` : u;
    return this.request(url, { method: 'GET' });
  },
  post(u, body) { return this.request(u, { method: 'POST', body }); },
  put(u, body) { return this.request(u, { method: 'PUT', body }); },
  delete(u, body) { return this.request(u, { method: 'DELETE', body }); },
};

// ========== Auth ==========
PP.Auth = {
  async login(email, password, remember = false) {
    return PP.API.post('/auth/login', { email, password, remember });
  },
  async register(payload) {
    return PP.API.post('/auth/register', payload);
  },
  async logout() {
    return PP.API.post('/auth/logout');
  },
  async me() {
    return PP.API.get('/auth/me');
  },
  async verifyEmail(otp) {
    return PP.API.post('/auth/verify-email', { otp });
  },
  async verifyPhone(otp) {
    return PP.API.post('/auth/verify-phone', { otp });
  },
  async resendOtp(type = 'email') {
    return PP.API.post('/auth/resend-otp', { type });
  },
  async setupPin(pin, confirm_pin) {
    return PP.API.post('/auth/setup-pin', { pin, confirm_pin });
  },
  async changePin(old_pin, new_pin) {
    return PP.API.post('/auth/change-pin', { old_pin, new_pin });
  },
  async verifyPin(pin) {
    return PP.API.post('/auth/verify-pin', { pin });
  },
  async forgotPassword(email) {
    return PP.API.post('/auth/forgot-password', { email });
  },
  async resetPassword(email, otp, new_password) {
    return PP.API.post('/auth/reset-password', { email, otp, new_password });
  },
  async updateProfile(payload) {
    return PP.API.put('/auth/update-profile', payload);
  },
  async walletQr() {
    return PP.API.get('/auth/wallet-qr');
  },
  renderForm(mode = 'login') {
    const wrap = PP.$('#authFormWrapper');
    if (!wrap) return;
    const isLogin = mode === 'login';
    wrap.innerHTML = '';
    const form = PP.el('form', {
      class: 'auth-form',
      onsubmit: async (e) => {
        e.preventDefault();
        const btn = PP.$('.auth-submit', form);
        btn.disabled = true; btn.innerHTML = '<i data-lucide="loader-2" style="animation:slowSpin 1s linear infinite"></i> Processing…';
        PP.refreshIcons();
        try {
          const fd = new FormData(form);
          const payload = Object.fromEntries(fd.entries());
          const res = isLogin
            ? await PP.Auth.login(payload.email, payload.password, payload.remember === 'on')
            : await PP.Auth.register(payload);
          PP.UI.toast(isLogin ? 'Welcome back!' : 'Account created', res.message || '', 'success');
          PP.state.user = res?.data?.user || null;
          setTimeout(() => { PP.bootstrap(true); }, 400);
        } catch (err) {
          PP.UI.toast('Error', err.message || 'Something went wrong', 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = isLogin ? 'Sign In' : 'Create Account';
        }
      },
    });
    form.innerHTML = `
      <h2 class="auth-title">${isLogin ? 'Sign in to PocketPay' : 'Create your account'}</h2>
      <p class="auth-subtitle">${isLogin ? 'Welcome back. Enter your details to continue.' : 'Start organizing every rupee, across every pocket.'}</p>
      ${!isLogin ? `
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input class="form-input" name="full_name" type="text" placeholder="Arjun Sharma" required minlength="2" />
        </div>` : ''}
      <div class="form-group">
        <label class="form-label">Email</label>
        <input class="form-input" name="email" type="email" placeholder="you@example.com" required />
      </div>
      ${!isLogin ? `
        <div class="form-group">
          <label class="form-label">Phone (optional)</label>
          <input class="form-input" name="phone" type="tel" placeholder="+91 98765 43210" />
        </div>` : ''}
      <div class="form-group">
        <label class="form-label">Password</label>
        <input class="form-input" name="password" type="password" placeholder="••••••••" required minlength="8" />
      </div>
      ${isLogin ? `
        <label class="checkbox-row">
          <input type="checkbox" name="remember" />
          <span>Remember me for 30 days</span>
        </label>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:.75rem;flex-wrap:wrap;margin:-.25rem 0 .75rem">
          <button type="button" class="link-btn forgot-btn" id="forgotBtn">Forgot password?</button>
        </div>` : `
        <div class="form-group">
          <label class="form-info">
            <i data-lucide="info" style="width:14px;height:14px;margin-right:4px"></i>
            By creating an account, you agree to PocketPay's Terms.
          </label>
        </div>`}
      <button type="submit" class="btn btn-primary btn-lg btn-block auth-submit">
        ${isLogin ? 'Sign In' : 'Create Account'}
      </button>
      <div class="auth-divider"><span>or</span></div>
      <div class="auth-switch">
        ${isLogin
          ? `<p>New to PocketPay? <button type="button" class="link-btn" id="goRegister">Create an account</button></p>`
          : `<p>Already have an account? <button type="button" class="link-btn" id="goLogin">Sign in</button></p>`}
      </div>`;
    wrap.appendChild(form);
    PP.refreshIcons();
    PP.$('#goRegister')?.addEventListener('click', () => {
      PP.$('#tabRegister').click();
    });
    PP.$('#goLogin')?.addEventListener('click', () => {
      PP.$('#tabLogin').click();
    });
    PP.$('#forgotBtn')?.addEventListener('click', async () => {
      const email = await PP.UI.prompt('Password Reset', 'Enter your account email', { type: 'email', placeholder: 'you@example.com' });
      if (!email) return;
      try {
        const res = await PP.Auth.forgotPassword(email);
        const otp = await PP.UI.prompt('Enter OTP', `We sent a 6-digit OTP to ${email}${res?.data?.reset_otp ? ` (dev: ${res.data.reset_otp})` : ''}`, { type: 'text' });
        if (!otp) return;
        const pwd = await PP.UI.prompt('New Password', 'Enter a new password (min 8 chars)', { type: 'password' });
        if (!pwd) return;
        await PP.Auth.resetPassword(email, otp, pwd);
        PP.UI.toast('Password reset', 'Sign in with your new password', 'success');
      } catch (e) { PP.UI.toast('Reset failed', e.message, 'error'); }
    });
  },
};

// ========== Misc / Summary ==========
PP.MiscAPI = {
  health() { return PP.API.get('/api/health'); },
  dashboard() { return PP.API.get('/api/summary/dashboard'); },
  icons() { return PP.API.get('/api/icon-options'); },
  colors() { return PP.API.get('/api/color-options'); },
  generateQR(content, size) { return PP.API.post('/api/qr/generate', { content, size }); },
};

// ========== Wallet ==========
PP.WalletAPI = {
  balance() { return PP.API.get('/api/wallet/balance'); },
  topup(amount, payment_method = 'upi', upi_reference) {
    return PP.API.post('/api/wallet/topup', { amount, payment_method, upi_reference });
  },
  withdraw(amount, description, payment_method = 'bank') {
    return PP.API.post('/api/wallet/withdraw', { amount, description, payment_method });
  },
  previewDistribution(total_amount, strategy, extras = {}) {
    return PP.API.post('/api/wallet/income/distribute/preview', { total_amount, strategy, ...extras });
  },
  executeDistribution(total_amount, strategy, extras = {}) {
    return PP.API.post('/api/wallet/income/execute', { total_amount, strategy, ...extras });
  },
  rules(params = {}) { return PP.API.get('/api/wallet/rules', params); },
  createRule(payload) { return PP.API.post('/api/wallet/rules', payload); },
  getRule(id) { return PP.API.get(`/api/wallet/rules/${id}`); },
  updateRule(id, payload) { return PP.API.put(`/api/wallet/rules/${id}`, payload); },
  deleteRule(id) { return PP.API.delete(`/api/wallet/rules/${id}`); },
  categories() { return PP.API.get('/api/wallet/categories'); },
};

// ========== Pockets ==========
PP.PocketsAPI = {
  list(params = {}) { return PP.API.get('/api/pockets', params); },
  get(id) { return PP.API.get(`/api/pockets/${id}`); },
  create(payload) { return PP.API.post('/api/pockets', payload); },
  update(id, payload) { return PP.API.put(`/api/pockets/${id}`, payload); },
  remove(id) { return PP.API.delete(`/api/pockets/${id}`); },
  rename(id, name) { return PP.API.put(`/api/pockets/${id}/rename`, { name }); },
  setColor(id, color) { return PP.API.put(`/api/pockets/${id}/color`, { color }); },
  setIcon(id, icon, icon_type = 'lucide') { return PP.API.put(`/api/pockets/${id}/icon`, { icon, icon_type }); },
  archive(id) { return PP.API.post(`/api/pockets/${id}/archive`); },
  restore(id) { return PP.API.post(`/api/pockets/${id}/restore`); },
  reorder(order) { return PP.API.post('/api/pockets/reorder', { order }); },
  transfer(from_pocket_id, to_pocket_id, amount, description) {
    return PP.API.post('/api/pockets/transfer', { from_pocket_id, to_pocket_id, amount, description });
  },
  transactions(id, params = {}) { return PP.API.get(`/api/pockets/${id}/transactions`, params); },
};

// ========== Transactions ==========
PP.TxAPI = {
  list(params = {}) { return PP.API.get('/api/transactions', params); },
  get(id) { return PP.API.get(`/api/transactions/${id}`); },
  previewExpense(pocket_id, amount, extras = {}) {
    return PP.API.post('/api/transactions/expense/preview', { pocket_id, amount, ...extras });
  },
  executeExpense(pocket_id, amount, pin, extras = {}) {
    return PP.API.post('/api/transactions/expense/execute', { pocket_id, amount, pin, ...extras });
  },
  transferPockets(from_pocket_id, to_pocket_id, amount, pin, description) {
    return PP.API.post('/api/transactions/transfer', { from_pocket_id, to_pocket_id, amount, pin, description });
  },
  timeline(months = 6) { return PP.API.get('/api/transactions/timeline', { months }); },
  refund(id, pin) { return PP.API.post(`/api/transactions/${id}/refund`, { pin }); },
  search(q) { return PP.API.get('/api/transactions/search', { q }); },
  recurringSuggestions() { return PP.API.get('/api/transactions/recurring/suggestions'); },
};

// ========== Analytics ==========
PP.AnalyticsAPI = {
  overview() { return PP.API.get('/api/analytics/overview'); },
  spendingByCategory(months = 1) { return PP.API.get('/api/analytics/spending-by-category', { months }); },
  spendingByPocket(months = 1) { return PP.API.get('/api/analytics/spending-by-pocket', { months }); },
  dailyTrend(days = 30) { return PP.API.get('/api/analytics/daily-trend', { days }); },
  budgetPerformance() { return PP.API.get('/api/analytics/budget-performance'); },
  insights() { return PP.API.get('/api/analytics/insights'); },
  notifications(params = {}) { return PP.API.get('/api/analytics/notifications', params); },
  markRead(id) { return PP.API.post(`/api/analytics/notifications/${id}/read`); },
  readAll() { return PP.API.post('/api/analytics/notifications/read-all'); },
  listBudgets() { return PP.API.get('/api/analytics/budgets'); },
  createBudget(payload) { return PP.API.post('/api/analytics/budgets', payload); },
  updateBudget(id, payload) { return PP.API.put(`/api/analytics/budgets/${id}`, payload); },
  deleteBudget(id) { return PP.API.delete(`/api/analytics/budgets/${id}`); },
};
