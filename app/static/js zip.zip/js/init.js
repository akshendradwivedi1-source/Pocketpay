// ========== Application Init ==========
document.addEventListener('DOMContentLoaded', async () => {
  PP.initTheme();
  PP.initRouter();
  PP.initSidebar();
  PP.initTopNav();
  PP.initFab();

  try { await PP.bootstrap(); }
  catch (e) { console.warn('bootstrap err', e); }

  window.addEventListener('hashchange', PP.handleRoute);

  setTimeout(PP.handleRoute, 40);

  setInterval(async () => {
    if (!PP.state.user) return;
    try {
      const res = await PP.AnalyticsAPI.notifications({ limit: 5 });
      const unread = (res?.data?.items || []).filter(n => !n.is_read).length;
      const badge = PP.$('#notifBadge');
      if (badge) { badge.textContent = unread > 0 ? (unread > 99 ? '99+' : unread) : ''; badge.style.display = unread > 0 ? '' : 'none'; }
    } catch (e) { /* ignore */ }
  }, 60000);

  try { PP.state.categories = await PP.WalletAPI.categories().then(r => r.data.categories); } catch (e) {}
});

PP.initSidebar = () => {
  const items = PP.$$('.sidebar .nav-item');
  const bottom = [];
  const applyActive = () => {
    const route = PP.currentRoute();
    [...items, ...bottom].forEach(i => {
      const to = i.getAttribute('data-route') || i.getAttribute('href')?.replace('#', '');
      const active = (route === to) || (to === 'dashboard' && route === '') || (to === 'budgets' && route === 'analytics');
      i.classList.toggle('active', !!active);
    });
  };
  window.addEventListener('pp:route', applyActive);
  setTimeout(applyActive, 40);

  const sidebar = document.querySelector('.sidebar');
  PP.$('#sidebarToggle')?.addEventListener('click', () => sidebar?.classList.toggle('open'));

  // Close sidebar on mobile when nav item clicked
  [...items, ...bottom].forEach(i => i.addEventListener('click', () => {
    if (window.innerWidth <= 960) sidebar?.classList.remove('open');
  }));

  // Sidebar quick actions
  PP.$('#sbAddIncome')?.addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    sidebar?.classList.remove('open');
    PP.Modals.addIncome();
  });
  PP.$('#sbAddExpense')?.addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    sidebar?.classList.remove('open');
    PP.Modals.addExpense();
  });
  PP.$('#sbTransfer')?.addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    sidebar?.classList.remove('open');
    PP.Modals.transfer();
  });
};

PP.initTopNav = () => {
  PP.$('#themeToggle')?.addEventListener('click', () => {
    const cur = document.documentElement.dataset.theme;
    PP.setTheme(cur === 'light' ? 'dark' : 'light');
  });

  PP.$('#notifBtn')?.addEventListener('click', async () => {
    const m = PP.UI.genericModal({
      title: 'Notifications', icon: 'bell', iconClass: 'bg-accent', size: 'md',
      body: (() => { const d = document.createElement('div'); d.id = 'notifList'; d.style.maxHeight = '60vh'; d.style.overflow = 'auto'; d.style.display = 'flex'; d.style.flexDirection = 'column'; d.style.gap = '.5rem'; return d; })(),
      footer: (() => {
        const wrap = document.createElement('div');
        wrap.style.display = 'flex';
        wrap.style.justifyContent = 'flex-end';
        wrap.style.gap = '.5rem';
        const allBtn = document.createElement('button');
        allBtn.className = 'btn btn-outline btn-sm';
        allBtn.innerHTML = '<i data-lucide="check" style="width:14px;height:14px"></i> Mark all read';
        allBtn.onclick = async () => { try { await PP.AnalyticsAPI.readAll(); PP.Wallet.loadNotifs(); } catch (e) {} };
        const closeBtn = document.createElement('button');
        closeBtn.className = 'btn btn-primary btn-sm';
        closeBtn.textContent = 'Close';
        closeBtn.onclick = () => m.close();
        wrap.appendChild(allBtn); wrap.appendChild(closeBtn);
        return wrap;
      })(),
    });
    setTimeout(() => PP.Wallet.loadNotifs(PP.$('#notifList', m.root || document.body)), 10);
  });

  // Avatar / profile dropdown (from header inline button)
  const avatarBtn = PP.$('#avatarBtn');
  const avatarDrop = PP.$('#avatarDropdown');
  const closeDrop = () => avatarDrop?.classList.remove('show');
  avatarBtn?.addEventListener('click', (e) => { e.stopPropagation(); avatarDrop?.classList.toggle('show'); });
  document.addEventListener('click', (e) => { if (!avatarDrop?.contains(e.target)) closeDrop(); });
  PP.$$('[data-route]', avatarDrop).forEach(b => b.addEventListener('click', () => {
    const r = b.getAttribute('data-route'); if (r) { closeDrop(); PP.navigate(r); }
  }));
  PP.$('#setupPinBtn')?.addEventListener?.('click', () => {
    closeDrop();
    const hasPin = !!PP.state.user?.transaction_pin_hash;
    hasPin ? PP.Modals.changePin() : PP.Modals.setupPin();
  });
  PP.$('#logoutBtn')?.addEventListener?.('click', () => { closeDrop(); PP.logout(); });

  // Global search: ⌘K + search box
  const gs = PP.$('#globalSearch');
  if (gs) {
    gs.addEventListener('focus', () => PP.navigate('transactions'));
    gs.addEventListener('input', PP.debounce(() => {
      const q = gs.value.trim();
      if (!q) return;
      PP.navigate('transactions', { search: q });
    }, 450));
    document.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        gs.focus();
        gs.select();
      }
    });
  }
};

PP.initFab = () => {
  // Desktop FAB (sidebar-visible) or large center FAB
  const fab = PP.$('#mobileFab') || PP.$('#bottomCenterFab') || PP.$('#fabMain');
  const fabMenu = PP.$('#mobileFabMenu') || PP.$('#fabMenu');
  if (fab && fabMenu) {
    fab.addEventListener('click', (e) => {
      e.stopPropagation();
      fab.classList.toggle('active');
      fabMenu.classList.toggle('open');
    });
    document.addEventListener('click', () => {
      fab.classList.remove('active');
      fabMenu.classList.remove('open');
    });
    fabMenu.addEventListener('click', (e) => e.stopPropagation());
    const closeFAB = () => { fab.classList.remove('active'); fabMenu.classList.remove('open'); };

    // Hook the menu buttons by action attribute
    PP.$$('.fab-item, [data-fab-action]', fabMenu).forEach(b => {
      const act = b.dataset.fabAction || b.dataset.action || b.id;
      b.addEventListener('click', () => {
        closeFAB();
        if (act === 'fab-income' || act === 'income') PP.Modals.addIncome();
        else if (act === 'fab-pay' || act === 'pay' || act === 'expense') PP.Modals.addExpense();
        else if (act === 'fab-transfer' || act === 'transfer') PP.Modals.transfer();
        else if (act === 'fab-pocket' || act === 'pocket') PP.Modals.createPocket();
      });
    });

    // Also match by IDs (fallback)
    PP.$('#fab-income, [data-action="income"]')?.addEventListener('click', () => { closeFAB(); PP.Modals.addIncome(); });
    PP.$('#fab-pay, [data-action="pay"]')?.addEventListener('click', () => { closeFAB(); PP.Modals.addExpense(); });
    PP.$('#fab-transfer, [data-action="transfer"]')?.addEventListener('click', () => { closeFAB(); PP.Modals.transfer(); });
    PP.$('#fab-pocket, [data-action="pocket"]')?.addEventListener('click', () => { closeFAB(); PP.Modals.createPocket(); });
  }

  // Bottom nav: by HTML class "bottom-item" (matches PP.updateNavState selector)
  PP.$$('.bottom-item').forEach(b => {
    b.addEventListener('click', () => {
      const r = b.getAttribute('data-route');
      if (r) PP.navigate(r);
      PP.$$('.bottom-item').forEach(x => x.classList.toggle('active', x === b));
    });
  });

  // Splash hide
  setTimeout(() => {
    const l = PP.$('#appLoader');
    if (l) {
      l.classList.add('hide');
      l.classList.add('loaded');
      setTimeout(() => l && (l.style.display = 'none'), 400);
    }
  }, 500);
};
